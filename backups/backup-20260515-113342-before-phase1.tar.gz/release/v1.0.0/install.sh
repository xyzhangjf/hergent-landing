#!/bin/bash
# ================================================
# Hermes AI 快消版 安装器
# 一键安装 Hermes Agent + dairy-pack profile + 配置API Key
# ================================================

set -e

DIR="$(cd "$(dirname "$0")" && pwd)"
RESOURCES="$DIR/../Resources"

# --- GUI 函数 ---
function gui_msg() {
  osascript -e "display dialog \"$1\" buttons {\"$2\"} default button 1 with title \"Hermes AI 快消版安装器\" with icon note" 2>/dev/null || true
}

function gui_input() {
  osascript -e "display dialog \"$1\" default answer \"\" with title \"Hermes AI 快消版安装器\" with icon note" 2>/dev/null | sed 's/.*text returned://'
}

function gui_confirm() {
  osascript -e "display dialog \"$1\" buttons {\"取消\",\"确定\"} default button 2 with title \"Hermes AI 快消版安装器\" with icon note" 2>/dev/null || true
}

function gui_error() {
  osascript -e "display dialog \"$1\" buttons {\"知道了\"} default button 1 with title \"Hermes AI 快消版 - 错误\" with icon stop" 2>/dev/null || true
}

function gui_progress() {
  osascript -e "
    set progressTotal to $2
    set progressItem to \"$1\"
    set progressDescription to \"$3\"
  " 2>/dev/null || true
}

# --- 步骤 1: 欢迎 ---
gui_msg "欢迎安装 Hermes AI 快消版 · 快消品全链路AI经营系统\n\n本安装器将自动完成以下步骤：\n1. 安装 Hermes AI 引擎\n2. 导入系统配置\n3. 配置 API Key\n\n预计时间：1-3分钟" "开始安装"

# --- 步骤 2: 安装 Homebrew（如需要）---
if ! command -v brew &>/dev/null; then
  gui_msg "正在安装 Homebrew（macOS包管理器）...\n这是安装 Hermes 的前提条件" "继续"
  /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)" 2>&1 | tail -3
fi

# --- 步骤 3: 安装 Hermes ---
if ! command -v hermes &>/dev/null; then
  gui_msg "正在安装 Hermes AI 引擎..." "继续"
  
  # 检查 Python
  if ! command -v python3 &>/dev/null; then
    gui_error "未检测到 Python3，请先安装 Python\nhttps://www.python.org/downloads/"
    exit 1
  fi

  pip3 install hermes-agent 2>&1 | tail -3
  
  # 添加到 PATH
  HERMES_PATH=$(python3 -m site --user-base)/bin
  if [[ ":$PATH:" != *":$HERMES_PATH:"* ]]; then
    echo "export PATH=\"\$PATH:$HERMES_PATH\"" >> ~/.zshrc
    export PATH="$PATH:$HERMES_PATH"
  fi
fi

# --- 步骤 4: 导入 Profile ---
PROFILE_FILE="$RESOURCES/dairy-pack.tar.gz"
if [ -f "$PROFILE_FILE" ]; then
  # 先检查是否已存在
  if [ -d "$HOME/.hermes/profiles/dairy-pack" ]; then
    result=$(gui_confirm "检测到已安装 Hermes AI 配置，是否覆盖更新？")
    if echo "$result" | grep -q "确定"; then
      hermes profile import "$PROFILE_FILE" --profile dairy-pack 2>&1 | tail -5
    fi
  else
    hermes profile import "$PROFILE_FILE" --profile dairy-pack 2>&1 | tail -5
  fi
fi

# --- 步骤 5: 配置 API Key ---
if [ ! -f "$HOME/.hermes/profiles/dairy-pack/.env" ] || ! grep -q "HERMES_API_KEY" "$HOME/.hermes/profiles/dairy-pack/.env" 2>/dev/null; then
  API_KEY=$(gui_input "请输入你的 API Key\n\n（推荐使用 DeepSeek API Key，免费注册获取）\n\n👉 如何获取 API Key？\n1. 用浏览器打开 platform.deepseek.com\n2. 注册/登录账号\n3. 点击左侧菜单「API Keys」\n4. 点击「Create API Key」，复制密钥\n\n密钥长这样：sk-xxxxxxxxxxxxxxxxx")
  if [ -n "$API_KEY" ]; then
    mkdir -p "$HOME/.hermes/profiles/dairy-pack"
    echo "HERMES_API_KEY=$API_KEY" > "$HOME/.hermes/profiles/dairy-pack/.env"
    echo "HERMES_MODEL=deepseek-chat" >> "$HOME/.hermes/profiles/dairy-pack/.env"
    echo "HERMES_PROVIDER=deepseek" >> "$HOME/.hermes/profiles/dairy-pack/.env"
  fi
fi

# --- 步骤 6: 创建数据目录 ---
mkdir -p "$HOME/Documents/流水对账/对账报告"
mkdir -p "$HOME/Documents/流水对账/银行流水"
mkdir -p "$HOME/Documents/流水对账/舟谱导出"

# --- 步骤 7: 创建桌面快捷方式 ---
SHORTCUT="$HOME/Desktop/Hermes AI 快消版.command"
cat > "$SHORTCUT" << 'EOF'
#!/bin/bash
cd "$(dirname "$0")"
if command -v hermes-fast消费品-electron &>/dev/null; then
  hermes-fast消费品-electron
elif [ -d "/Applications/Hermes AI 快消版.app" ]; then
  open "/Applications/Hermes AI 快消版.app"
else
  echo "请先安装 Hermes AI 快消版桌面应用"
fi
EOF
chmod +x "$SHORTCUT"

# --- 完成 ---
gui_msg "🎉 安装完成！\n\nHermes AI 快消版已成功安装到你的电脑\n\n桌面快捷方式已创建\n\n现在可以通过桌面上的「Hermes AI 快消版」图标使用" "打开应用"

# 如果安装了Electron应用，启动它
if [ -d "/Applications/Hermes AI 快消版.app" ]; then
  open "/Applications/Hermes AI 快消版.app"
fi

exit 0
