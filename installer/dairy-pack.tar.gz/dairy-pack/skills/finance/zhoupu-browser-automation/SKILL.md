---
name: zhoupu-browser-automation
version: 2.0.0
description: 舟谱ERP系统全自动化操作——涵盖沙箱Browser登录、CDP连接本地Chrome、阿里云滑块破解、数据导出、订单导入。基于编程虾2026年5月方案+多轮实战验证。
tags: [舟谱, Browser, Playwright, CDP, 自动化, 登录, 导出, 导入, 阿里云滑块]
---

# 舟谱Browser自动化操作技能

## 触发条件

当需要全自动操作舟谱系统时：
- 自动导出收支明细/应收明细/回款流水
- 自动导入订单模板（自提/调拨订单）
- 自动登录舟谱
- 用户问"你帮我登录舟谱"

## 两种技术路线

| 路线 | 工具 | 跨域iframe | 登录方式 | 文件上传 |
|------|------|-----------|---------|---------|
| **Browser沙箱** | Playwright（Hermes内置） | ✅ 无限制 | 需过阿里云滑块 | ✅ Browser upload能力 |
| **CDP本地Chrome** | websockets + CDP协议 | ❌ 受限制 | 用户已登录 | ❌ 系统对话框不行 |

---

## 第一章：CDP连接本地Chrome（已验证实战可行）

### 1.1 启动Chrome调试模式

先在用户电脑上启动Chrome调试：

```bash
# 杀掉已有Chrome
pkill -9 -f "Google Chrome" 2>/dev/null; sleep 2

# 以调试模式启动
/Applications/Google\ Chrome.app/Contents/MacOS/Google\ Chrome \
  --remote-debugging-port=28800 \
  --no-first-run \
  --no-default-browser-check \
  --user-data-dir=/tmp/chrome-debug
```

浏览器启动后，用户手动登录舟谱，并导航到目标页面。

### 1.2 查找目标tab

```bash
curl -s http://localhost:28800/json | python3 -c "
import sys,json
tabs=json.load(sys.stdin)
for t in tabs:
    if 'zhoupudata' in t.get('url',''):
        print(t['webSocketDebuggerUrl'])
"
```

### 1.3 CDP核心操作模板

```python
import asyncio, websockets, json

async def send(ws, msg):
    await ws.send(json.dumps(msg))
    return json.loads(await ws.recv())

async def main():
    async with websockets.connect(WS_URL) as ws:
        # 导航（通过主页面hash路由）
        await send(ws, {"id": 1, "method": "Page.navigate", "params": {
            "url": "https://portal.zhoupudata.com/saas/main#/procureSale/selfPick"
        }})
        await asyncio.sleep(3)
        
        # 鼠标点击（React SPA必须用低级别事件）
        await send(ws, {"id": 2, "method": "Input.dispatchMouseEvent", "params": {
            "type": "mousePressed", "x": 1095, "y": 149,
            "button": "left", "clickCount": 1
        }})
        await send(ws, {"id": 3, "method": "Input.dispatchMouseEvent", "params": {
            "type": "mouseReleased", "x": 1095, "y": 149,
            "button": "left", "clickCount": 1
        }})
        
        # 截图
        r = await send(ws, {"id": 4, "method": "Page.captureScreenshot", "params": {"format": "png"}})
        import base64
        with open("/tmp/screenshot.png", "wb") as f:
            f.write(base64.b64decode(r["result"]["data"]))

asyncio.run(main())
```

### 1.4 已验证的页面坐标（Chrome 147, 1920×1080）

**自提订单页面（`#/procureSale/selfPick`）：**

| 元素 | 坐标 (x, y) | 说明 |
|------|------------|------|
| 导出按钮 | 1016, 136 | 页面右上角 |
| 批量操作按钮 | 1095, 149 | 展开Dropdown下拉菜单 |
| 批量导入菜单项 | 1140, 186 | Dropdown第一个项 |
| 导出/导入（右上角菜单） | 849, 26 | 顶栏右侧 |

### 1.5 舟谱ERP的hash路由表

| 页面 | Hash路由 |
|------|---------|
| 自提订单 | `#/procureSale/selfPick` |
| 调拨订单 | `#/procureSale/transfer` |
| 应收汇总表 | `#/dataReport/ReceivableSummary` |
| 账户收支明细 | `#/report/financeFlow` |

### 1.6 CDP的已知限制

1. **跨域iframe限制** — 舟谱ERP内容在 `statics.zhoupudata.com` 的iframe中，主页面(`portal.zhoupudata.com`)无法通过CDP读取iframe内DOM。`Runtime.evaluate` + `frameId` 对跨域iframe无效。
2. **独立target session丢失** — `Target.createTarget` 创建的erp独立页面`Page.navigate`后session丢失。
3. **文件上传不可行** — file input在iframe内，系统文件对话框CDP无法控制。
4. **DDropdown菜单坐标可能因窗口大小变化** — 建议先用TreeWalker动态计算。

---

## 第二章：Browser沙箱方案（需要破解阿里云滑块）

### 2.1 阿里云滑块分析

舟谱登录页 (`portal.zhoupudata.com/saas/tologin`) 使用阿里云滑块验证码。

**关键DOM结构：**
```html
<div id="aliyunCaptcha-window-popup" class="aliyunCaptcha-hidden">
  <div id="aliyunCaptcha-sliding-wrapper">
    <div id="aliyunCaptcha-sliding-slider">...</div>
  </div>
</div>
```

- 滑块默认隐藏（`aliyunCaptcha-hidden`），点击登录按钮后才显示
- 验证通过后设置 `ncCheckFlag = true`
- 验证通过参数包括 `nc_sid`、`nc_ver`、`nc_token` 等

### 2.2 已尝试但失败的JS绕过方法

以下方法已验证无法绕过阿里云滑块：

| 方法 | 结果 |
|------|------|
| `document.querySelector('form').submit()` | 被拦截，回到登录页 |
| `fetch POST` 带`credentials:'include'` | 返回主页面HTML但set-cookie不写入 |
| `XMLHttpRequest` 同步POST | 同源策略阻止set-cookie |
| 隐藏iframe form提交 | 无set-cookie |
| 设置`captcha_login_id`后提交 | 服务端不认 |
| 调用`captchaVerifyCallback` | 无实际效果 |
| 设置`ncCheckFlag=true` | 仅前端状态，服务端验证失败 |
| 注入`nc_sid`/`nc_token`等隐藏参数 | 验证失败 |
| 从CDP拿cookie注入Browser沙箱(`document.cookie`) | HttpOnly的SESSION/authorization无法用JS设置 |

### 2.3 推荐的破解方向（需进一步研究）

**方案A：undetected-chromedriver + OpenCV图像识别**

依赖安装：
```bash
pip3 install undetected-chromedriver selenium opencv-python numpy pillow ddddocr
```

参考仓库：
- `StorbMec/aliyun-captcha-bypass`（3⭐, Python）
- `mucsbr/aliyun-captcha-fake`（34⭐, Python，有授权机制）

核心思路：
1. 用 `undetected-chromedriver` 启动Chrome（绕过反爬）
2. 截图滑块背景图，用OpenCV/ddddocr识别缺口位置
3. 用Selenium ActionChains 模拟人类拖动（分段+随机偏移）

注意：`undetected-chromedriver` 启动的Chrome会弹出GUI窗口，在无显示器的服务器上可能需用Xvfb等虚拟显示方案。

**方案B：Composio v3 API**
- DeepSeek推荐，需注册Composio账号获取v3 API Key
- 当前版本0.7.21的v2 API已下线
- 尚未验证在舟谱场景下的可行性

---

## 第三章：订单导入CDP实战流程（已验证可行）

### 3.1 完整操作步骤

```python
# 1. 连接主页面tab
WS_URL = "ws://localhost:28800/devtools/page/..."

async with websockets.connect(WS_URL) as ws:
    # 2. 导航到自提订单页
    await navigate(ws, "https://portal.zhoupudata.com/saas/main#/procureSale/selfPick")
    
    # 3. 点击"批量操作"按钮
    await mouse_click(ws, 1095, 149)
    await asyncio.sleep(1.5)  # 等待Dropdown动画
    
    # 4. 点击"批量导入"菜单项
    await mouse_click(ws, 1140, 186)
    await asyncio.sleep(2)  # 等待弹窗加载
    
    # 5. 告诉用户手动选文件上传（系统对话框无法自动）
    # "请在Chrome中选择文件 → 自提订单导入模板_20260504.xlsx → 立即导入"
```

### 3.2 注意事项

- 先导入调拨订单，再导入自提订单（两个流程独立）
- 每次点击后加 `delayMs: 2000-3000`，不要连续快速操作
- 用 `Page.captureScreenshot` 截图验证页面状态
- 如果Dropdown未展开，可重试点击批量操作

---

## 第四章：Cookie提取与复用

### 4.1 从CDP获取cookie

```python
r = await send(ws, {"id": 1, "method": "Network.getAllCookies"})
cookies = r["result"]["cookies"]
# 提取关键cookie
for c in cookies:
    if c["name"] in ["authorization", "SESSION", "cid", "uid"]:
        print(f"{c['name']}={c['value'][:30]}...")
```

### 4.2 关键cookie

| Cookie名 | 域 | 说明 |
|----------|-----|------|
| `authorization` | portal/statics.zhoupudata.com | JWT token（HttpOnly） |
| `SESSION` | portal.zhoupudata.com | 会话ID（HttpOnly） |
| `cid` | portal/statics | 企业ID |
| `uid` | portal/statics | 用户ID |

### 4.3 用requests直接访问（不依赖浏览器）

```python
import requests
headers = {
    "Cookie": "SESSION=xxx; authorization=xxx; cid=xxx; uid=1"
}
r = requests.get("https://portal.zhoupudata.com/saas/main", headers=headers)
# 返回200+主页面HTML表示有效
```

---

## 第五章：蒙牛CRM

### 登录地址
```
http://crm.mengniu.cn/sap(bD16aCZjPTgwMCZkPW1pbg==)/bc/bsp/sap/crm_ui_start/default.htm
```

### 登录字段
| 字段 | 默认值 |
|------|--------|
| 系统 | CRP |
| 客户端 | 800 |
| 语言 | 中文 |

---

## 附录：参考资源

- 编程虾方案原文：`references/bianchengxia-solution.md`
- GitHub滑块破解仓库：`StorbMec/aliyun-captcha-bypass`, `mucsbr/aliyun-captcha-fake`
- Cookie获取脚本模板：`templates/cdp_get_cookies.py`
