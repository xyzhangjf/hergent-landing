# 阿里云滑块验证码破解方案调研

> 2026年5月4日更新

## 已验证不可行的方案（舟谱场景）

### 1. 前端JS绕过

所有在Browser沙箱中通过JS绕过滑块的方法均失败：

| 方法 | 结果 |
|------|------|
| 直接设置 `ncCheckFlag=true` | 服务端不认前端状态 |
| `form.submit()` | 被拦截回登录页 |
| fetch POST `credentials:'include'` | set-cookie不写入document |
| XMLHttpRequest 同步POST | 同源策略阻止 |
| 隐藏form提交 | 无set-cookie |
| 注入 `captcha_login_id` 伪造值 | 服务端不认 |
| `captchaVerifyCallback()` 回调 | 无实际效果 |
| 构造 `nc_sid`/`nc_token` 隐藏参数 | 验证失败 |

### 2. Cookie注入

从CDP获取已登录Chrome的cookie后通过 `document.cookie` 注入Browser沙箱：

- 非HttpOnly的cookie可以设置（如cid、uid）
- HttpOnly的cookie（SESSION、authorization）无法用JS设置
- 即使设置了cid/uid，服务端因缺少SESSION而拒绝登录

### 3. CDP独立target

- `Target.createTarget` 创建的erp页面有登录内容但 `Page.navigate` 后session丢失
- ERP target连接不稳定（有时返回HTTP 500）
- 跨域iframe导致CDP无法读取 `statics.zhoupudata.com` 的DOM内容

---

## 需进一步研究的方案

### 方案A：undetected-chromedriver + 图像识别

**参考仓库：**
- `StorbMec/aliyun-captcha-bypass`（3⭐）— Python, Selenium + 图像分析
- `mucsbr/aliyun-captcha-fake`（34⭐）— 有授权机制，需申请

**原理：**
1. `undetected-chromedriver` 启动Chrome（绕过反爬检测）
2. 用Selenium打开舟谱登录页
3. 截图滑块背景图
4. OpenCV/ddddocr 识别滑块缺口位置
5. ActionChains 模拟人类拖动

**依赖安装（已执行）：**
```bash
pip3 install undetected-chromedriver selenium opencv-python numpy pillow ddddocr
```

**风险：** undetected-chromedriver 在macOS无GUI环境可能无法启动（需Xvfb等虚拟显示方案）。

### 方案B：Composio v3 API

- DeepSeek推荐方案
- 当前CLI版本0.7.21的v2 API已下线
- 需注册Composio账号获取v3 API Key
- 未验证

### 方案C：用requests直接调舟谱API

- 已验证：用CDP获取cookie后，`requests.get` 直接访问主页面返回200（20万字节HTML）
- 如果能找到舟谱的数据导出API接口，可以不通过浏览器直接调API导出数据
- 需要抓到舟谱前端的数据导出请求
