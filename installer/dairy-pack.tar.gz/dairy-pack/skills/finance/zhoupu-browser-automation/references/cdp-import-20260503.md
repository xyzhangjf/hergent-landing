# 2026年5月3日 订单导入实战记录

## 背景

5月4日到货的蒙牛+简爱订单，需要生成自提和调拨两个模板并导入舟谱。

## CDP导入完整流程

### 启动Chrome调试

```bash
# 确保之前的Chrome已关闭
pkill -9 -f "Google Chrome"
sleep 2

# 启动
/Applications/Google\ Chrome.app/Contents/MacOS/Google\ Chrome \
  --remote-debugging-port=28800 \
  --no-first-run \
  --no-default-browser-check \
  --user-data-dir=/tmp/chrome-debug
```

### 用户操作

1. 在Chrome中打开 `https://portal.zhoupudata.com/saas/main`
2. 手动登录
3. 导航到自提订单页面

### Agent操作步骤

1. `curl http://localhost:28800/json` 找到舟谱tab的WS URL
2. 连接主页面tab（**不是** erp独立target）
3. 执行mouse click操作

### 遇到的坑

1. **不要用 `Target.createTarget` 创建erp独立页面** — session不共享，`Page.navigate` 后session丢失
2. **不要试图操作iframe内DOM** — 跨域限制，DOM.getDocument返回空
3. **Dropdown菜单项坐标需动态计算** — 窗口大小不同坐标不同
4. **批量操作按钮点击后需等待1.5-2秒** — Ant Design Dropdown有动画
5. **文件上传无法自动完成** — 系统级文件对话框CDP无法控制

### 验证的行之有效的坐标（Chrome 147, 标准窗口）

| 页面 | 元素 | 坐标 |
|------|------|------|
| 自提订单页 | 批量操作按钮 | 1095, 149 |
| 自提订单页 | 批量导入菜单项 | 1140, 186 |

坐标获取方法：用TreeWalker找到文本节点，计算 `getBoundingClientRect()` 的中心点。
