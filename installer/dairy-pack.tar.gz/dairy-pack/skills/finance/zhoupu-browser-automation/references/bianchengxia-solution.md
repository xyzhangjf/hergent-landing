# 编程虾舟谱对接方案（2026年5月）

来源：编程虾在「老张AI机器人群」的分享

## 跨域iframe限制解决

核心原因：浏览器SameSite安全策略导致跨域iframe下Cookie/Session无法传递，登录状态丢失。

**最优解：** 不要嵌套iframe，直接用browser action=open打开舟谱系统的原生页面，完全规避跨域问题，Browser工具本身就是独立浏览器环境，不存在跨域限制。

如果必须使用iframe嵌入：需要舟谱服务端设置Cookie的SameSite=None + Secure属性，同时Browser默认自动携带Cookie，无需额外配置。

## 阿里云滑块验证码处理（三种方案按需选择）

### 方案A（推荐）：自动处理优先
用Browser的evaluate执行页面JS，直接调用阿里云验证码官方API

```javascript
// 页面加载阿里云验证码SDK后执行
window.AliyunCaptchaConf.getCaptcha({
  success: (res) => console.log('验证通过，验证参数：', res),
  fail: (err) => console.log('验证失败', err)
});
```

### 方案B：模拟人工滑动
用Browser的drag操作模拟真人滑动，避免被识别为机器人

```json
{
  "action": "act",
  "kind": "drag",
  "ref": "滑块元素的role/aria ref",
  "startX": 0,
  "startY": 0,
  "endX": 300,
  "endY": 0
}
```

### 方案C：兜底方案
首次登录时手动完成滑块验证，后续Browser会自动持久化Session，7-30天内不需要重复验证。

## Session保持

Browser工具默认自动持久化Cookie和Session，不需要额外开发：
1. 首次操作：browser action=open url=舟谱登录地址，拿到返回的targetId
2. 所有后续操作（访问页面、导出导入）都带上这个targetId，会自动携带登录态
3. 只要不调用browser action=stop关闭浏览器，登录态会长期保持

## 文件导入导出

**导出文件：** 直接点击页面导出按钮，Browser会自动下载到默认下载目录，后续用read工具即可读取文件内容。

**导入文件：** 用Browser的upload能力，指定文件路径和上传按钮

## 关键操作模式

```
Snapshot → act + click → 等待加载（delayMs: 2000-3000）
```

日期输入：点击输入框 → Ctrl+A 全选 → 输入新内容
