# 独立生成舟谱自提+调拨订单导入模板的Python脚本
# 纯openpyxl版（不依赖pandas）
# 用法：python3 /path/to/gen_both.py

# 注意事项：
# 1. 修改 ARRIVAL_DATE、ORDER_FILE_MN、ORDER_FILE_JA 为实际值
# 2. 简爱客户列差异：刘小顶→刘顶，美联配送→美联檀溪店
# 3. 序号从01开始
# 4. 自提单只含分销商+门店，调拨单只含调拨业务员

# 完整脚本看 /tmp/gen_both.py（2026年5月3日版本）
