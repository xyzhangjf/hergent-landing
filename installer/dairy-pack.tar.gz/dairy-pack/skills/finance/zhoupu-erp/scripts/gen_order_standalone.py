"""独立生成舟谱自提订单导入模板（纯openpyxl版）- 单次调用的简化版本

用法:
  python gen_order_standalone.py
"""
import openpyxl
from openpyxl.styles import Font, Alignment

# === 配置 ===
ORDER_FILE = "/path/to/下单表.xlsx"
PRICE_FILE = "/path/to/价格表.xlsx"
ARRIVAL_DATE = "20260504"
SHEET_NAME = "4月30报单-5月4到货"
OUTPUT_FILE = f"自提订单导入模板_{ARRIVAL_DATE}.xlsx"

# === 自提客户配置 ===
ZITI_COLS = ["唐成", "黄家伟", "易胜琳", "胡奎奎", "朱青峰", "谢总",
             "吾悦", "东津", "民发", "沃尔玛", "美联配送", "檀溪美联"]

CUSTOMER_MAPPING = {
    "易胜琳": "易胜玲", "谢总": "宜城谢总",
    "吾悦": "永辉吾悦店", "东津": "永辉东津店", "民发": "永辉民发店",
    "檀溪美联": "美联檀溪店", "美联配送": "美联檀溪店",
}

PRICE_RULES = {
    "唐成": "分销价格", "黄家伟": "分销价格", "易胜琳": "分销价格",
    "胡奎奎": "分销价格", "朱青峰": "分销价格", "谢总": "分销价格",
    "吾悦": "永辉价格", "东津": "永辉价格", "民发": "永辉价格",
    "沃尔玛": "沃尔玛价格", "檀溪美联": "美联价格", "美联配送": "美联价格",
}

# === 实现代码同 gen_both_orders.py 中的自提部分 ===
# 参考 gen_both_orders.py 中的 load_price_table, read_sheet_data, 
# extract_orders_by_cols(is_ziti=True), generate_ziti_excel
print("参考 gen_both_orders.py，使用其中的自提订单生成部分")
print("本文件为占位符，实际功能由 gen_both_orders.py 提供")
