#!/usr/bin/env python3
"""
微信支付账单 vs 舟谱系统(账户1003011张俊峰微信)对账脚本
匹配逻辑：
  收入：微信收入(收/支=收入) ↔ 舟谱收款单+预收款单
  支出：微信支出(收/支=支出) ↔ 舟谱内部费用单+付款单
  零钱提现/经营账户提现：记录差异，不匹配（提现到银行卡是另一个账户的事）
"""
import openpyxl
from datetime import datetime, timedelta
from collections import defaultdict

# ========== 1. 读取微信流水 ==========
def load_wechat(fn):
    wb = openpyxl.load_workbook(fn, read_only=False, data_only=True)
    ws = wb.active
    rows = list(ws.iter_rows(values_only=True))
    wb.close()

    # header: 交易时间,交易类型,交易对方,商品,收/支,金额(元),支付方式,当前状态,交易单号,商户单号,备注
    inc = []  # 收入
    exp = []  # 支出
    withdraw = []  # 提现到银行卡（不参与对账，记录差异）

    for r in rows[1:]:
        if not r[0] or r[5] is None:
            continue
        t = r[0]  # datetime
        trade_type = str(r[1]) if r[1] else ''
        counter = str(r[2]) if r[2] else ''
        direction = str(r[4]) if r[4] else ''
        amount = float(r[5])
        note = str(r[3]) if r[3] else ''
        remark = str(r[10]) if r[10] else ''
        tx_no = str(r[8]) if r[8] else ''

        rec = {
            'date': t.date() if hasattr(t, 'date') else t,
            'time': t,
            'trade_type': trade_type,
            'counter': counter,
            'direction': direction,
            'amount': amount,
            'note': note,
            'remark': remark,
            'tx_no': tx_no,
        }

        if direction == '收入':
            inc.append(rec)
        elif direction == '支出':
            exp.append(rec)
        elif '提现' in trade_type or '经营账户提现' in trade_type:
            withdraw.append(rec)

    return inc, exp, withdraw

# ========== 2. 读取舟谱微信账户(1003011) ==========
def load_zhoupu_wechat(fn):
    wb = openpyxl.load_workbook(fn, read_only=False, data_only=True)
    ws = wb.active
    rows = list(ws.iter_rows(values_only=True))
    wb.close()

    # 从行557开始(1003011)到下个账户之前
    in_wx = False
    wx_rows = []
    for i, r in enumerate(rows):
        if r[0] and str(r[0]).strip() == '1003011':
            in_wx = True
        if in_wx:
            if r[0] and str(r[0]).strip() not in ('1003011',) and r[1] and '小计' not in str(r[1]):
                break
            wx_rows.append(r)

    # 跳过表头(前5行包含期初余额等)
    # 列：账户编号,账户名称,单据时间,单据编号,单据类型,单据状态,收入,支出,账户余额,结算单位,供应商,收/付款人,备注
    inc = []
    exp = []
    for r in wx_rows[1:]:  # 跳过期初余额
        if not r[2] or (r[4] == '期初余额'):
            continue
        date_str = str(r[2])[:10]
        try:
            d = datetime.strptime(date_str, '%Y-%m-%d').date()
        except:
            continue

        inc_amt = r[6] if r[6] else 0
        exp_amt = r[7] if r[7] else 0
        doc_type = str(r[4]) if r[4] else ''
        unit = str(r[9]) if r[9] else ''
        payee = str(r[11]) if r[11] else ''
        note = str(r[12]) if r[12] else ''
        doc_no = str(r[3]) if r[3] else ''

        rec = {
            'date': d,
            'time': r[2],
            'doc_no': doc_no,
            'doc_type': doc_type,
            'unit': unit,
            'payee': payee,
            'inc': inc_amt,
            'exp': exp_amt,
            'note': note,
        }

        if inc_amt != 0:
            inc.append(rec)
        if exp_amt != 0:
            exp.append(rec)

    return inc, exp

# ========== 3. 匹配函数 ==========
def match_income(wechat_inc, zhoupu_inc):
    """微信收入 vs 舟谱收款单+预收款单
    策略：同金额+同日期 or 同金额+±1天（微信记录的是付款到账日，舟谱记录的是收款日）
    """
    matched = []       # (wc, zp, match_type)
    wc_unmatched = []
    zp_used = set()    # index of zhoupu records used

    # 构建舟谱索引：按金额分组
    zp_by_amt = defaultdict(list)
    for i, z in enumerate(zhoupu_inc):
        zp_by_amt[abs(z['inc'])].append(i)

    for wc in wechat_inc:
        amt = wc['amount']
        d = wc['date']
        counter = wc['counter']

        # 优先：同金额+同日
        candidates = zp_by_amt.get(amt, [])
        best = None
        for zi in candidates:
            if zi in zp_used:
                continue
            z = zhoupu_inc[zi]
            if z['date'] == d:
                # 可选：检查对方是否相关
                best = (zi, 'exact')
                break

        # 其次：同金额+±1天
        if best is None:
            for delta in [-1, 1]:
                cand_date = d + timedelta(days=delta)
                for zi in candidates:
                    if zi in zp_used:
                        continue
                    z = zhoupu_inc[zi]
                    if z['date'] == cand_date:
                        best = (zi, f'±1day({delta:+d})')
                        break
                if best:
                    break

        if best:
            zp_used.add(best[0])
            matched.append((wc, zhoupu_inc[best[0]], best[1]))
        else:
            wc_unmatched.append(wc)

    # 未匹配的舟谱收入
    zp_unmatched = [zhoupu_inc[i] for i in range(len(zhoupu_inc)) if i not in zp_used]

    return matched, wc_unmatched, zp_unmatched

def match_expense(wechat_exp, zhoupu_exp):
    """微信支出 vs 舟谱内部费用单+付款单
    注意：舟谱内部费用单的费用类型记在note字段（如"98号汽油¥232"），微信备注记在remark字段
    匹配策略：同金额+同日期
    """
    matched = []
    wc_unmatched = []
    zp_used = set()

    zp_by_amt = defaultdict(list)
    for i, z in enumerate(zhoupu_exp):
        zp_by_amt[abs(z['exp'])].append(i)

    for wc in wechat_exp:
        amt = wc['amount']
        d = wc['date']

        candidates = zp_by_amt.get(amt, [])
        best = None
        for zi in candidates:
            if zi in zp_used:
                continue
            z = zhoupu_exp[zi]
            if z['date'] == d:
                best = (zi, 'exact')
                break

        if best:
            zp_used.add(best[0])
            matched.append((wc, zhoupu_exp[best[0]], best[1]))
        else:
            wc_unmatched.append(wc)

    zp_unmatched = [zhoupu_exp[i] for i in range(len(zhoupu_exp)) if i not in zp_used]

    return matched, wc_unmatched, zp_unmatched

# ========== 4. 生成报告 ==========
def gen_report(wechat_inc, wechat_exp, wechat_withdraw,
              zhoupu_inc, zhoupu_exp,
              matched_inc, um_wc_inc, um_zp_inc,
              matched_exp, um_wc_exp, um_zp_exp, month):

    wc_inc_total = sum(r['amount'] for r in wechat_inc)
    wc_exp_total = sum(r['amount'] for r in wechat_exp)
    wc_wd_total = sum(r['amount'] for r in wechat_withdraw)
    zp_inc_total = sum(abs(r['inc']) for r in zhoupu_inc)
    zp_exp_total = sum(abs(r['exp']) for r in zhoupu_exp)

    lines = []
    lines.append(f"# 微信对账报告（{month}）")
    lines.append("")
    lines.append("## 账户：张俊峰微信")
    lines.append("")
    lines.append(f"| 项目 | 微信流水 | 舟谱(1003011) |")
    lines.append(f"|------|----------|---------------|")
    lines.append(f"| 收入 | ¥{wc_inc_total:,.2f}（{len(wechat_inc)}笔） | ¥{zp_inc_total:,.2f}（{len(zhoupu_inc)}笔） |")
    lines.append(f"| 支出 | ¥{wc_exp_total:,.2f}（{len(wechat_exp)}笔） | ¥{zp_exp_total:,.2f}（{len(zhoupu_exp)}笔） |")
    lines.append(f"| 提现到银行卡 | ¥{wc_wd_total:,.2f}（{len(wechat_withdraw)}笔） | — |")
    lines.append("")
    lines.append(f"**已匹配：收入 {len(matched_inc)} 组，支出 {len(matched_exp)} 组**")
    lines.append("")

    # 未匹配收入（微信有，舟谱无）
    lines.append(f"### 未匹配收入（微信有，舟谱无）- {len(um_wc_inc)}笔")
    if um_wc_inc:
        lines.append("| 时间 | 对方 | 金额 | 交易类型 | 备注 | 原因 | 建议 |")
        lines.append("|------|------|------|----------|------|------|------|")
        total = 0
        for r in sorted(um_wc_inc, key=lambda x: x['time']):
            counter = r['counter']
            # 判断原因
            if '退款' in r['note'] or '退款' in r['remark'] or r['remark']:
                reason = '退款'
            else:
                reason = '微信已收，舟谱未录'
            lines.append(f"| {r['time'].strftime('%m-%d')} | {counter[:15]} | ¥{r['amount']:,.2f} | {r['trade_type']} | {r['note'][:20]} | {reason} | 补录 |")
            total += r['amount']
        lines.append(f"| **合计** | | **¥{total:,.2f}** | | | | |")
    else:
        lines.append("无")
    lines.append("")

    # 未匹配收入（舟谱有，微信无）
    lines.append(f"### 未匹配收入（舟谱有，微信无）- {len(um_zp_inc)}笔")
    if um_zp_inc:
        lines.append("| 时间 | 结算单位 | 金额 | 单据类型 | 备注 | 原因 | 建议 |")
        lines.append("|------|----------|------|----------|------|------|------|")
        total = 0
        for r in sorted(um_zp_inc, key=lambda x: x['date']):
            reason = '舟谱已录，微信未收'
            lines.append(f"| {r['date']} | {r['unit'][:15]} | ¥{abs(r['inc']):,.2f} | {r['doc_type']} | {r['note'][:15]} | {reason} | 核查 |")
            total += abs(r['inc'])
        lines.append(f"| **合计** | | **¥{total:,.2f}** | | | | |")
    else:
        lines.append("无")
    lines.append("")

    # 未匹配支出（微信有，舟谱无）
    lines.append(f"### 未匹配支出（微信有，舟谱无）- {len(um_wc_exp)}笔")
    if um_wc_exp:
        lines.append("| 时间 | 对方 | 金额 | 交易类型 | 备注 | 原因 | 建议 |")
        lines.append("|------|------|------|----------|------|------|------|")
        total = 0
        for r in sorted(um_wc_exp, key=lambda x: x['time']):
            counter = r['counter']
            reason = '微信已付，舟谱未录'
            lines.append(f"| {r['time'].strftime('%m-%d')} | {counter[:15]} | ¥{r['amount']:,.2f} | {r['trade_type']} | {r['note'][:20]} | {reason} | 补录 |")
            total += r['amount']
        lines.append(f"| **合计** | | **¥{total:,.2f}** | | | | |")
    else:
        lines.append("无")
    lines.append("")

    # 未匹配支出（舟谱有，微信无）
    lines.append(f"### 未匹配支出（舟谱有，微信无）- {len(um_zp_exp)}笔")
    if um_zp_exp:
        lines.append("| 时间 | 收/付款人 | 金额 | 单据类型 | 备注 | 原因 | 建议 |")
        lines.append("|------|----------|------|----------|------|------|------|")
        total = 0
        for r in sorted(um_zp_exp, key=lambda x: x['date']):
            lines.append(f"| {r['date']} | {r['payee'][:15]} | ¥{abs(r['exp']):,.2f} | {r['doc_type']} | {r['note'][:15]} | 舟谱已录，微信未付 | 核查 |")
            total += abs(r['exp'])
        lines.append(f"| **合计** | | **¥{total:,.2f}** | | | | |")
    else:
        lines.append("无")
    lines.append("")

    # 提现差异
    lines.append(f"### 零钱提现记录（微信→银行卡，共{len(wechat_withdraw)}笔，金额¥{wc_wd_total:,.2f}）")
    lines.append("（提现到银行卡不计入微信账户对账，在银行账户对账中处理）")
    lines.append("")
    lines.append("| 时间 | 类型 | 金额 | 服务费 | 状态 |")
    lines.append("|------|------|------|--------|------|")
    for r in sorted(wechat_withdraw, key=lambda x: x['time']):
        fee = 0
        if r['remark'] and '¥' in r['remark']:
            try:
                fee = float(r['remark'].split('¥')[1].replace('服务费', '').replace('元', '').replace(')', ''))
            except:
                pass
        lines.append(f"| {r['time'].strftime('%m-%d')} | {r['trade_type']} | ¥{r['amount']:,.2f} | ¥{fee:.2f} | {r.get('status','')} |")
    lines.append("")

    # 退款/负数处理说明
    neg_inc = [r for r in zhoupu_inc if r['inc'] < 0]
    if neg_inc:
        lines.append("### 舟谱退款记录（收入为负数）")
        lines.append("| 时间 | 结算单位 | 金额 | 原因 |")
        lines.append("|------|----------|------|------|")
        for r in neg_inc:
            lines.append(f"| {r['date']} | {r['unit'][:15]} | ¥{r['inc']:,.2f} | {r['note'][:15]} |")
        lines.append("（退款冲减收入，微信侧可能已原路退回或未体现）")
        lines.append("")

    return '\n'.join(lines)

# ========== 主函数 ==========
def main():
    wechat_file = "/Users/zhangjunfeng/Documents/流水对账/微信支付账单流水文件(20260301-20260331)_20260420192332.xlsx"
    zhoupu_file = "/Users/zhangjunfeng/Documents/流水对账/账户收支明细表 (2026年3月) (1).xlsx"
    out_file = "/Users/zhangjunfeng/Documents/流水对账/微信对账报告_2026年3月.md"

    print("读取微信流水...")
    wc_inc, wc_exp, wc_withdraw = load_wechat(wechat_file)
    print(f"  微信收入: {len(wc_inc)}笔 ¥{sum(r['amount'] for r in wc_inc):,.2f}")
    print(f"  微信支出: {len(wc_exp)}笔 ¥{sum(r['amount'] for r in wc_exp):,.2f}")
    print(f"  零钱提现: {len(wc_withdraw)}笔 ¥{sum(r['amount'] for r in wc_withdraw):,.2f}")

    print("读取舟谱微信账户...")
    zp_inc, zp_exp = load_zhoupu_wechat(zhoupu_file)
    print(f"  舟谱收入: {len(zp_inc)}笔 ¥{sum(abs(r['inc']) for r in zp_inc):,.2f}")
    print(f"  舟谱支出: {len(zp_exp)}笔 ¥{sum(abs(r['exp']) for r in zp_exp):,.2f}")

    print("匹配收入...")
    matched_inc, um_wc_inc, um_zp_inc = match_income(wc_inc, zp_inc)
    print(f"  已匹配: {len(matched_inc)}笔")

    print("匹配支出...")
    matched_exp, um_wc_exp, um_zp_exp = match_expense(wc_exp, zp_exp)
    print(f"  已匹配: {len(matched_exp)}笔")

    print("生成报告...")
    report = gen_report(
        wc_inc, wc_exp, wc_withdraw,
        zp_inc, zp_exp,
        matched_inc, um_wc_inc, um_zp_inc,
        matched_exp, um_wc_exp, um_zp_exp,
        '2026年3月'
    )

    with open(out_file, 'w', encoding='utf-8') as f:
        f.write(report)
    print(f"报告已保存: {out_file}")
    print()
    print(report)

if __name__ == '__main__':
    main()