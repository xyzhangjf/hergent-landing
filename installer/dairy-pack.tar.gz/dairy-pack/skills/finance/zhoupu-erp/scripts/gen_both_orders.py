"""合并生成蒙牛+简爱的舟谱自提订单+调拨订单导入模板（纯openpyxl版，无pandas依赖）
支持多品牌合并、自提/调拨区分、序号从01开始。"""
import openpyxl
from openpyxl.styles import Font, Alignment

def load_price_table(price_file):
    wb = openpyxl.load_workbook(price_file, data_only=True)
    ws = wb['数据源']
    info = {}
    for row in ws.iter_rows(min_row=2, values_only=True):
        barcode = row[1]
        if barcode is None:
            continue
        barcode_str = str(int(barcode)) if isinstance(barcode, float) else str(barcode).strip()
        info[barcode_str] = {
            '单位': row[5] or '',
            '简称': row[3] or '',
            '分销价格': round(float(row[6]), 2) if row[6] is not None else None,
            '永辉价格': round(float(row[7]), 2) if row[7] is not None else None,
            '沃尔玛价格': round(float(row[8]), 2) if row[8] is not None else None,
            '美联价格': round(float(row[9]), 2) if row[9] is not None else None,
        }
    wb.close()
    return info
