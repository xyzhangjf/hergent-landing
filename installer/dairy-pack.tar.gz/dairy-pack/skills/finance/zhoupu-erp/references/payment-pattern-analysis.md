# 客户回款规律分析 — 详细参考

> 内容源自原 `payment-pattern-analysis` 技能。包含完整的数据读取脚本、分析脚本和注意事项。

## 数据源格式

使用 **舟谱系统 → 数据报表 → 账户收支明细** 导出的 Excel 文件。

- 文件名：`账户收支明细表YYYY年MM月.xlsx`
- 表头行（第5行）：账户编号、账户名称、单据时间、单据编号、单据类型、单据状态、收入、支出、账户余额、结算单位、供应商、收/付款人、备注
- 数据从第6行开始
- 第1-4行为元数据（标题、导出时间、筛选条件）
- 可能有合并单元格，使用 `openpyxl` 而非 `pandas.read_excel` 读取

### 最少数据量要求
- **最少3个月**数据才能看出规律
- **推荐6个月**以上数据得到可靠结论
- 每月一个文件，按年月命名

## 分析流程

### 第一步：数据读取与清洗

```python
import openpyxl
from collections import defaultdict

base = "/path/to/zhoupufile"
files = sorted([f for f in os.listdir(base) if f.endswith('.xlsx')])

all_records = []
for fname in files:
    wb = openpyxl.load_workbook(os.path.join(base, fname))
    ws = wb.active
    for r in range(6, ws.max_row + 1):
        c5 = ws.cell(row=r, column=5).value
        if c5 is None: continue
        if '收款' in str(c5) or '回单' in str(c5):
            all_records.append({
                'file': fname,
                'time': ws.cell(row=r, column=3).value,
                'doc_no': ws.cell(row=r, column=4).value,
                'doc_type': str(c5).strip(),
                'income': float(ws.cell(row=r, column=7).value or 0),
                'customer': str(ws.cell(row=r, column=10).value or '').strip(),
            })
```

### 第二步：按客户汇总

指标：回款次数、总金额、平均每笔、最大/最小单笔、回款日期序列。

### 第三步：周期分析

```python
intervals = []
for i in range(1, len(dates)):
    delta = dates[i] - dates[i-1]
    intervals.append(delta.days)
avg_interval = sum(intervals) / len(intervals)
```

### 第四步：分类识别

| 类型 | 平均间隔 | 典型客户 | 催款策略 |
|------|---------|---------|---------|
| **日结型** | 1-3天 | 多多买菜、各吃货基地小店 | 无需催款 |
| **周结型** | 4-10天 | 君乐宝客户（胡军）、绿环连锁 | 每周跟踪 |
| **半月结型** | 11-20天 | 部分连锁超市、小型食堂 | 半月跟踪 |
| **月结型** | 21-40天 | 唐成、永辉民发店、各学校 | **重点催款对象** |
| **季结/学期结** | >40天 | 铁路职高食堂 | 学期前催款 |

### 第五步：星期偏好分析

统计回款落在周几的分布。经验规律：周三-周五是回款高峰，周六日明显下降。

### 第六步：催款优先级公式

```
优先级 = (平均间隔天数 × 总金额) / (标准差 + 1)
```
值越高 → 金额大且周期长 → 最需关注。

## 注意事项

### 常见陷阱
1. **合并单元格**：舟谱导出文件表头有合并单元格，不要用 pandas.read_excel
2. **日期跨月**：2月文件可能包含了3月上旬的数据
3. **T+1到账的干扰**：微信/支付宝支付T+1到账，分析时应剔除第三方平台流水
4. **内部转账/退款**：负数冲抵需单独标记，不要计入正常回款
5. **账户差异**：库存现金账户的收款是实际现金交易，银行存款账户才是银行转账
6. **回款人的区别**：「结算单位」是真正的客户，「收/付款人」是操作人

### 周期性识别技巧
- **学校客户**：学期制，寒暑假间隔异常长（60-90天），学期内每月回款
- **超市连锁**：统一结算，每月固定日期附近回款
- **食堂/餐饮**：通常有固定周期（每周或每月）
- **多多买菜等平台**：每日自动结算，无需催款
