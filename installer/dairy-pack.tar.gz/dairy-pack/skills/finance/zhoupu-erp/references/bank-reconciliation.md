# 银行流水对账 — 详细参考

> 内容源自原 `bank-reconciliation` 技能。包含银行流水格式细节、脚本使用说明应对的技巧。

## 各银行流水格式

### 工行流水
- 文件格式：xlsx，Sheet0
- 列：凭证号、本方账号、对方账号、交易时间、借贷、借方发生额、贷方发生额、对方行号、摘要、用途、对方单位名称、余额
- 收入看贷方发生额，支出看借方发生额

### 建行流水
- 实际为.xls格式（CDFV2），需用xlrd读取
- Sheet0，前4行为表头
- 交易金额正数=收入，负数=支出

### 邮储流水
- 文件格式：.xls（需xlrd读取）
- 前3行为表头信息
- 交易金额正数=收入（贷方），负数=支出（借方）
- 特殊摘要：`公转私` 表示公户→个人户内部转账

### 微信流水
- 文件格式：xlsx，Sheet1
- 列：交易时间、交易类型、交易对方、商品、收/支、金额(元)、支付方式、当前状态、交易单号、商户单号、备注
- 经营收款/经营账户提现走微信经营账户，不进个人零钱
- 零钱提现不计入微信账户对账（在银行账户对账中处理）
- 合并录入匹配：同日同人合并、同日不同人合并

### 支付宝流水
- 文件格式：xlsx，12列
- 收/支=收入/支出/不计收支
- 不计收支=提现到银行卡

### 农信流水（湖北农商银行）
- PDF格式，用pypdfium2提取
- 发生额正数=收入，负数=支出

## 脚本参考

以下脚本已迁移到 `scripts/` 目录下：

| 脚本 | 用途 |
|------|------|
| `reconcile_v2.py` | 工行流水对账（主要版本） |
| `reconcile_v2.1.py` | 工行对账改进版 |
| `reconcile_postal.py` | 邮储银行对账 |
| `reconcile_wechat.py` | 微信流水对账 |
| `reconcile_alipay.py` | 支付宝流水对账 |
| `reconcile_simple_t1_fee.py` | T+1手续费简单对账 |
| `pdf_extract.py` | PDF流水提取（农信银行） |
| `check_balance.py` | 余额检查 |
| `find_patterns.py` | 对账模式识别 |
| `summarize_patterns.py` | 模式汇总 |
| `verify_more_dates.py` | 多日期验证 |
| `verify_t1_fee.py` | T+1手续费验证 |

## 环境注意事项

- python3 执行需加 `-S -E` 标志
- 加了 -S -E 后需手动添加 site-packages 路径
- openpyxl 读 .xls 报错，需用 xlrd
- numpy 2.x 与 Python 3.9 不兼容，需降级到 1.24.4
- PDF流水用 pypypdfium2 提取（已安装）
- 舟谱Excel有合并单元格，需用 read_only=False + data_only=True
