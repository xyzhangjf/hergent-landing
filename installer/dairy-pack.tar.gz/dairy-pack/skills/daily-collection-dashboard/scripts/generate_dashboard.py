#!/usr/bin/env python3
"""
每日催收看板生成脚本
从舟谱导出的回款流水+应收款明细生成看板

使用方式:
    python3 generate_dashboard.py

依赖:
    openpyxl (非 pandas — 舟谱Excel混合类型列会报错)
"""
from datetime import datetime
import openpyxl
from collections import defaultdict
import sys

FLOW_PATH = "/Users/zhangjunfeng/Documents/流水对账/舟谱流水/账户收支明细表4月全账户.xlsx"
RECV_PATH = "/Users/zhangjunfeng/Documents/流水对账/应收款明细表(2025年1月-2026年5月1日).xlsx"
REFERENCE_DATE = datetime.now()

# 已知预收款客户（不报超额异常）
KNOWN_PREPAY_CUSTOMERS = {
    '宜城谢总', '黄家伟', '唐成', '多多买菜', '易胜玲', '楚汉高中', '耀襄高中',
    '刘正宝', '汇博盛高中', '果蔬生鲜馆', '嗨特卖（丹江路）', '常春蔬果（七里河店）',
}


def read_flow(path):
    """读取舟谱收支明细 - 用openpyxl（pandas会报混合类型列错误）"""
    wb = openpyxl.load_workbook(path, data_only=True)
    ws = wb.active
    rows = list(ws.iter_rows(min_row=6, values_only=True))
    records = []
    for r in rows:
        if r[0] is None or r[0] == '账户编号':
            continue
        acct_name = str(r[1] or '').strip()
        if '小计' in acct_name or '合计' in acct_name:
            continue
        records.append({
            '账户编号': str(r[0] or '').strip(),
            '账户名称': acct_name,
            '单据时间': str(r[2] or ''),
            '单据编号': str(r[3] or ''),
            '单据类型': str(r[4] or ''),
            '单据状态': str(r[5] or ''),
            '收入': float(r[6]) if r[6] is not None else 0.0,
            '支出': float(r[7]) if r[7] is not None else 0.0,
            '账户余额': float(r[8]) if r[8] is not None else 0.0,
            '结算单位': str(r[9] or '').strip(),
            '备注': str(r[12] or '').strip(),
        })
    return records


def read_receivables(path):
    """读取舟谱应收款明细 - 用openpyxl"""
    wb = openpyxl.load_workbook(path, data_only=True)
    ws = wb.active
    rows = list(ws.iter_rows(min_row=8, values_only=True))
    records = []
    for r in rows:
        if r[0] is None or str(r[0]).strip() == '结算单位':
            continue
        customer = str(r[0]).strip()
        if '小计' in customer or '合计' in customer:
            continue
        date_str = str(r[1] or '').strip()
        date_val = None
        if date_str:
            try:
                date_val = datetime.strptime(date_str[:10], '%Y-%m-%d')
            except ValueError:
                pass
        records.append({
            '结算单位': customer,
            '日期': date_val,
            '期末余额': float(r[8]) if r[8] is not None else None,
        })
    return records


def generate_dashboard(flow_path, recv_path, reference_date=None):
    """生成催收看板数据"""
    if reference_date is None:
        reference_date = datetime.now()

    flow = read_flow(flow_path)
    recv = read_receivables(recv_path)

    # --- 今日回款 ---
    receipts = [r for r in flow if r['单据类型'] in ('收款单', '预收款单')]
    total_income = sum(r['收入'] for r in receipts)
    total_count = len(receipts)

    by_customer = defaultdict(float)
    for r in receipts:
        by_customer[r['结算单位']] += r['收入']
    sorted_customers = sorted(by_customer.items(), key=lambda x: -x[1])
    top_receipts = [(c, a) for c, a in sorted_customers if a > 0][:10]

    # --- 当前欠款 ---
    latest_balance = {}
    for r in recv:
        if r['期末余额'] is not None:
            latest_balance[r['结算单位']] = r['期末余额']
    owes = {c: b for c, b in latest_balance.items() if b > 0}
    sorted_owes = sorted(owes.items(), key=lambda x: -x[1])
    top_owes = sorted_owes[:10]
    total_owes = sum(owes.values())

    # --- 逾期计算 ---
    latest_record = {}
    for r in recv:
        if r['期末余额'] is not None and r['日期'] is not None and r['期末余额'] > 0:
            cust = r['结算单位']
            if cust not in latest_record or r['日期'] > latest_record[cust]['日期']:
                latest_record[cust] = r

    overdue_list = []
    for cust, rec in latest_record.items():
        days = (reference_date - rec['日期']).days
        if days >= 30:
            overdue_list.append({
                '结算单位': cust,
                '期末余额': rec['期末余额'],
                '逾期天数': days,
            })
    overdue_list.sort(key=lambda x: -x['期末余额'])
    severe = [o for o in overdue_list if o['逾期天数'] >= 90]
    normal_overdue = [o for o in overdue_list if 30 <= o['逾期天数'] < 90]

    # --- 异常检测 ---
    alerts = []
    # 1. 无客户名大额回款
    for r in receipts:
        cust = r['结算单位']
        if any(kw in cust for kw in ['零售', '散客', '其他']) and r['收入'] > 500:
            alerts.append(f"📌 无明确客户名的回款：{cust} ¥{r['收入']:.2f}（{r['单据时间']}）")
    # 2. 超额回款（跳过已知预收款客户）
    for cust in set(r['结算单位'] for r in receipts):
        if cust in KNOWN_PREPAY_CUSTOMERS or cust not in owes or owes[cust] <= 0:
            continue
        total_pay = sum(r['收入'] for r in receipts if r['结算单位'] == cust)
        if total_pay > owes[cust] * 1.5 and total_pay > 5000:
            alerts.append(f"📌 {cust} 回款 {total_pay:.2f} 远超欠款 {owes[cust]:.2f}，请确认是否转预收")
    # 3. 大额负数退款
    for r in receipts:
        if r['收入'] < 0 and abs(r['收入']) > 100:
            alerts.append(f"📌 退款：{r['结算单位']} ¥{abs(r['收入']):.2f}（{r['单据时间']}，{r['单据类型']}）")

    return {
        'today_count': total_count,
        'today_total': total_income,
        'top_receipts': top_receipts,
        'top_owes': top_owes,
        'severe': severe,
        'normal_overdue': normal_overdue,
        'total_owes': total_owes,
        'overdue_count': len(overdue_list),
        'alerts': alerts,
        'reference_date': reference_date,
    }


def format_dashboard(data):
    """格式化看板为手机端可读文本"""
    date_str = data['reference_date'].strftime('%-m月%-d日')
    lines = [f"📅 {date_str} 催收看板"]

    # 今日回款
    lines.append("")
    lines.append("▶ 今日回款（4月全账户）")
    lines.append(f"  ✅ 共 {data['today_count']} 笔，合计 ¥{data['today_total']:,.2f}")
    if data['top_receipts']:
        lines.append("  大额回款：")
        for cust, amt in data['top_receipts']:
            lines.append(f"    {cust:<20s} ¥{amt:>8,.2f}")

    # 当前欠款TOP10
    lines.append("")
    lines.append(f"▶ 当前欠款TOP10（共欠¥{data['total_owes']:,.2f}）")
    for cust, amt in data['top_owes']:
        lines.append(f"  {cust:<24s} ¥{amt:>8,.2f}")
    lines.append(f"  其中 {data['overdue_count']} 家逾期30天以上")

    # 严重逾期（90天+）— 只显示TOP15
    if data['severe']:
        lines.append("")
        lines.append("▶ ❗ 严重逾期（90天以上）TOP15")
        for o in data['severe'][:15]:
            lines.append(f"  {o['结算单位']:<24s} ¥{o['期末余额']:>8,.2f}  逾期{o['逾期天数']}天")
        if len(data['severe']) > 15:
            lines.append(f"  ... 共{len(data['severe'])}家严重逾期客户")

    # 30-90天逾期 — 只显示欠款≥500元
    if data['normal_overdue']:
        filtered = [o for o in data['normal_overdue'] if o['期末余额'] >= 500]
        if filtered:
            lines.append("")
            lines.append(f"▶ ⚠️ 逾期客户（30-90天, 欠款≥500元）")
            for o in filtered:
                lines.append(f"  {o['结算单位']:<24s} ¥{o['期末余额']:>8,.2f}  逾期{o['逾期天数']}天")
            if len(filtered) < len(data['normal_overdue']):
                lines.append(f"  ... 另有{len(data['normal_overdue']) - len(filtered)}家小额逾期客户")

    # 异常检测
    lines.append("")
    lines.append("▶ 异常检测")
    if data['alerts']:
        for a in data['alerts']:
            lines.append(f"  {a}")
    else:
        lines.append("  ✅ 今日无异常")
    lines.append("")

    return "\n".join(lines)


if __name__ == '__main__':
    # 自动匹配最新文件
    import os, glob
    
    flow_dir = os.path.expanduser("~/Documents/流水对账/舟谱流水/")
    recv_dir = os.path.expanduser("~/Documents/流水对账/")

    flow_files = sorted(glob.glob(os.path.join(flow_dir, "账户收支明细表*.xlsx")), key=os.path.getmtime)
    recv_files = sorted(glob.glob(os.path.join(recv_dir, "应收款明细表*.xlsx")), key=os.path.getmtime)

    if not flow_files:
        print("❌ 未找到账户收支明细表文件")
        sys.exit(1)
    if not recv_files:
        print("❌ 未找到应收款明细表文件")
        sys.exit(1)

    flow_path = flow_files[-1]
    recv_path = recv_files[-1]

    print(f"📄 回款流水: {os.path.basename(flow_path)}", file=sys.stderr)
    print(f"📄 应收明细: {os.path.basename(recv_path)}", file=sys.stderr)
    print(file=sys.stderr)

    data = generate_dashboard(flow_path, recv_path)
    report = format_dashboard(data)
    print(report)
