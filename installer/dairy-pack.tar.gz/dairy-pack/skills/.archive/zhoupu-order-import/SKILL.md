---
name: zhoupu-order-import
description: 舟谱系统订单导入模板生成（自提订单+调拨订单）+ 舟谱系统登录与手动导入指引
tags: [舟谱, 订单, 导入, 自提, 调拨]
---

# 舟谱系统订单导入（模板生成 + 手动导入）

## 完整业务流程（低温奶行业 - 短保产品）

1. **报单**：业务员/导购/分销商用飞书多维表格或企业微信智能表格报单（报单日→到货日）
2. **汇总成Excel**：张俊峰从飞书多维表格导出或直接获取报单Excel
3. **审核**：将汇总数据发给**郝洋**（销售经理）审核修改
4. **生成模板**：郝洋确认后，运行脚本生成舟谱导入模板
5. **手动导入舟谱系统**：因舟谱有图形验证码反爬，无法自动登录，需用户手动操作

## 舟谱系统登录与操作限制

### 登录信息
- **登录地址**: https://portal.zhoupudata.com/saas/main
- **用户名**: 18671058882
- **密码**: Abbott22!

### ⚠️ 登录限制
Hermes内置浏览器工具无法直接登录舟谱系统，原因：
1. 舟谱使用**阿里云滑动验证码**（AliyunCaptcha），需要人机交互
2. 还有图形验证码（4位数字字母，/saas/Verifycode接口）
3. 内置浏览器栈有反爬检测（页面会清空为空白）
4. curl等直连方式验证码始终校验失败（session绑定问题）

### 🎯 CDP 两大用途

Chrome远程调试（CDP）不仅能用于**订单导入**，更广泛应用于**数据导出**（对账所需数据）：

| 用途 | 说明 |
|------|------|
| **导出对账数据**（高频） | 舟谱流水、客户应收明细、供应商对账单 → 导出CSV → 用于每日/每月对账 |
| **导入订单模板**（低频） | 上传Excel模板 → 批量导入自提/调拨订单 |

两者使用同一套CDP技术（导航货架页面 → 点击 → 下载/上传）。
## 舟谱系统登录与操作限制

### 登录信息
- **登录地址**: https://portal.zhoupudata.com/saas/main
- **用户名**: 18671058882
- **密码**: Abbott22!

### ⚠️ 登录限制
Hermes内置浏览器工具无法直接登录舟谱系统，原因：
1. 舟谱使用**阿里云滑动验证码**（AliyunCaptcha），需要人机交互
2. 还有图形验证码（4位数字字母，/saas/Verifycode接口）
3. 内置浏览器栈有反爬检测（页面会清空为空白）
4. curl等直连方式验证码始终校验失败（session绑定问题）

### ✅ Chrome远程调试方案（已验证可行但有限制）

**通过CDP控制已登录Chrome的方法**已验证可行（2026年5月2日测试）：

1. **Chrome可行 ✅，QQ浏览器不可行 ❌**
   - Google Chrome支持 `--remote-debugging-port=9222`，CDP正常工作
   - QQ浏览器启动调试参数后崩溃退出，不支持CDP调试模式
   - **注意：** 启动调试模式的Chrome需要用 `--user-data-dir=` 指定你已有登录状态的用户数据目录，否则舟谱需要重新扫码登录
   - 当前Chrome用户数据目录（实测可用）：
     ```
     --user-data-dir="/Users/zhangjunfeng/Library/Application Support/Google/Chrome/Profile 1"
     ```

2. **CDP能做的事：**
   - 截图页面（`Page.captureScreenshot`）
   - 通过 `Page.navigate` 导航到hash route（如 `#/report/financeFlow`）
   - 在主页面外壳执行JS

3. **CDP做不到的事（跨域iframe限制）：**
   - ⛔ 舟谱ERP内容在 `statics.zhoupudata.com` 的跨域iframe里
   - ⛔ 主页面(`portal.zhoupudata.com`)无法访问iframe DOM
   - ⛔ CDP的 `Target.getTargets` 不暴露iframe为独立target
   - ⛔ `Runtime.evaluate` 在主页面上尝试 `contentDocument` → 返回 `CROSS_ORIGIN`
   - ⛔ **结论：无法通过CDP自动点击按钮、读取表格数据、执行导出操作**

4. **实际可用方案：用户手动导出文件**
   由于CDP无法操作iframe内部，对于舟谱系统来说，最可靠的方案是：
   - 引导用户手动操作（见下方话术）
   - 用户导出CSV/Excel文件后，Hermes自动处理

### Chrome标签页管理（通过CDP）
```python
import requests, json, asyncio, websockets

resp = requests.get("http://localhost:9222/json")
tabs = resp.json()
# 找已登录的舟谱页面
tab = [t for t in tabs if 'portal.zhoupudata.com/saas/main' in t.get('url', '')][0]
ws_url = tab['webSocketDebuggerUrl']

async def send_cmd(ws, cmd):
    await ws.send(json.dumps(cmd))
    return json.loads(await ws.recv())

async def main():
    async with websockets.connect(ws_url) as ws:
        # 执行JS
        result = await send_cmd(ws, {"id": 1, "method": "Runtime.evaluate", "params": {
            "expression": "document.body.innerText.substring(0, 1000)"
        }})
        print(result['result']['result']['value'])
        
        # 截图
        result = await send_cmd(ws, {"id": 2, "method": "Page.captureScreenshot", "params": {"format": "png"}})
        import base64
        img_data = base64.b64decode(result['result']['data'])
        with open('/tmp/screenshot.png', 'wb') as f:
            f.write(img_data)

asyncio.run(main())
```

### 备用方案：引导用户手动操作
当上述方案不可行时（用户无Chrome、无登录session等），使用以下话术引导用户操作：

```markdown
舟谱系统的验证码防护导致我无法自动登录。你已在QQ浏览器登录了，请在QQ浏览器上操作以下步骤：

**自提订单导入：**
1. 打开 https://portal.zhoupudata.com/saas/main（你已登录）
2. 采销管理 → 自提订单 → 批量操作 → 批量导入
3. 选择文件 → `/Users/zhangjunfeng/Documents/舟谱自提订单导入模板_YYYYMMDD.xlsx`
4. 上传 → 立即导入

**调拨订单导入（如需）：**
5. 采销管理 → 调拨订单 → 批量操作 → 批量导入
6. 选择文件 → `/Users/zhangjunfeng/Documents/舟谱调拨订单导入模板_YYYYMMDD.xlsx`
7. 上传 → 立即导入
```

## 飞书多维表格设计（替代企业微信智能表格）

舟谱报单Excel的典型结构是 **横向布局**（每行=一个产品，每列=一个经销商），需要转换为 **纵向布局** 的飞书多维表格以实现行权限隔离。

### 飞书多维表格字段设计

| 字段名 | 字段类型 | 说明 |
|---|---|---|
| 条码 | 文本 | 条形码 |
| 产品名称 | 文本 | 产品简称 |
| 规格 | 数字 | 每箱数量（可选） |
| 数量 | 数字 | 订货量 |
| 报单日期 | 日期 | 本次报单日期 |
| 到货日期 | 日期 | 本次到货日期 |
| **填报人** | **人员**（飞书人员字段） | 用于行权限隔离 |
| 备注 | 文本 | 订单排期等信息 |

### 数据转换：横向→纵向（Unpivot）

原始Excel结构：
```
产品名称 | 唐成 | 王琴 | 刘正宝 | ...
红桶     | 50   | 20   |       | ...
```

转换后（每行=一个经销商对一个产品的订货）：
```
产品名称 | 填报人 | 数量
红桶     | 唐成  | 50
红桶     | 王琴  | 20
```

### 权限设置
- 按「填报人」字段设置**行权限**，每个人只能看到 `填报人 = 自己` 的记录
- 管理员（张俊峰/郝洋）设置为可查看全部

### 自动化提醒（推荐3个）
1. **提交确认**：新记录创建时 → 通知填报人「提交成功」
2. **管理员通知**：新记录创建时 → 通知张俊峰「xxx 已提交订单」
3. **催单提醒**：每天截止时间 → 通知未提交的人「请尽快报单」

## 手动导入操作路径（必知）—— 唯一可靠的方案

**2026年5月2日实测结论：** CDP无法操作舟谱ERP的跨域iframe内容，所有自动化导入/导出操作必须通过用户手动完成。

### 舟谱系统手动操作路径

#### 自提订单导入
```
采销管理 → 自提订单 → 批量操作 → 批量导入
→ 选择文件 → 上传 → 立即导入
```

#### 调拨订单导入
```
采销管理 → 调拨订单 → 批量操作 → 批量导入
→ 选择文件 → 上传 → 立即导入
```

#### 数据导出（对账用）
```
资金 → 资金管理 → 账户收支明细
→ 选择账户 + 日期范围 → 导出Excel/CSV
→ 文件命名规范：`<账户名>_<年月>.xlsx`
```

### 模板文件存放路径
- 自提模板: `/Users/zhangjunfeng/Documents/舟谱自提订单导入模板_YYYYMMDD.xlsx`
- 调拨模板: `/Users/zhangjunfeng/Documents/舟谱调拨订单导入模板_YYYYMMDD.xlsx`

### 第三方工具：订单牛
- 用户有时使用「订单牛」生成舟谱订单导入模板
- 订单牛生成的模板文件命名格式：`舟谱自提订单导入模板_YYYYMMDD.xlsx` 和 `舟谱调拨订单导入模板_YYYYMMDD.xlsx`
- 存放路径：`/Users/zhangjunfeng/Documents/`
- 订单牛生成的模板可直接导入舟谱系统，无需脚本再处理
- 如果用户说"订单牛做好了"，直接引导手动导入即可（跳过程序生成步骤）

## 注意事项
- 短保产品需提前报单（报单日和到货日不同）
- 审核环节必须经过郝洋，不能跳过
- 生成模板后务必手动导入舟谱（见上方指引）
- 如果用订单牛生成了模板，直接跳转到手动导入步骤

## 脚本

### 1. 自提订单
```bash
python scripts/generate_order_import.py \
  --order <下单表.xlsx> \
  --price <价格表.xlsx> \
  --arrival <到货日期YYYYMMDD>
```

### 2. 调拨订单
```bash
python scripts/generate_transfer_order.py \
  --order <下单表.xlsx> \
  --price <价格表.xlsx> \
  --arrival <到货日期YYYYMMDD>
```

## 业务规则

### 自提订单
- 分销商用分销价格，门店用对应价格（永辉/沃尔玛/美联）
- 客户名称映射：易胜琳→易胜玲，谢总→宜城谢总，吾悦→永辉吾悦店等
- **源单据号格式：ZT+日期+序号（如ZT2026040801）**
- 固定值：业务员=张俊峰，部门=湖北福宝商贸有限公司，仓库=总仓

### 调拨订单
- 调拨业务员：程欢欢、刘善涛、毛辉、周运潘、田顺达、王琴、刘正宝
- 调出仓=总仓，调入仓=业务员名+仓（如程欢欢仓）
- 源单据号格式：DB+日期+序号（如DB2026040801）
- **商品条码是必填字段**

## 常见问题

### 导入失败：成功0条，失败N条
最常见原因：源单据号格式错误。检查ZT/DB前缀。
排查方法：下载已成功导入的样表对照格式。

### 价格缺失
某些条码在价格表中没有对应价格。可用 `--extra-prices` 补充。

### 商品条码浮点数问题
Excel中长条码被存为科学计数法，脚本已用 int() 转整数字符串。

### 起始序号冲突
舟谱系统已有01~20的单号，默认从21开始。再次导入需用更大序号避开冲突。

## 客户配置

分销商: 唐成、黄家伟、易胜琳、易胜玲、胡奎奎、朱青峰、谢总
永辉门店: 吾悦、东津、民发
沃尔玛: 沃尔玛
美联门店: 檀溪美联

价格类型：分销价格、永辉价格、沃尔玛价格、美联价格
