#!/usr/bin/env python3
"""
支付宝对账脚本
用法: python3 reconcile_alipay.py <支付宝流水.xlsx> <舟谱支付宝收支明细.xlsx>

匹配逻辑:
- 收入/支出: 纯金额匹配（不限日期，因为舟谱日期可能录错）
- 提现: 不计收支，跳过对账，在银行账户对账中处理
- 日期偏差匹配成功标"日期偏差，确认相符"
"""

import zipfile
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta
import sys

def excel_date(val):
    try:
        return datetime(1899, 12, 30) + timedelta(days=float(val))
    except:
        return None

def parse_xlsx(path):
    with zipfile.ZipFile(path) as z:
        with z.open("xl/sharedStrings.xml") as f:
            ss_tree = ET.parse(f)
        ns = {"x": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}
        strings = []
        for si in ss_tree.findall(".//x:si", ns):
            t = "".join(t.text or "" for t in si.findall(".//x:t", ns))
            strings.append(t)
        with z.open("xl/worksheets/sheet1.xml") as f:
            ws_tree = ET.parse(f)
        rows = []
        for row in ws_tree.findall(".//x:row", ns):
            r = []
            for c in row.findall("x:c", ns):
                t = c.get("t", "n")
                v = c.find("x:v", ns)
                if v is None:
                    r.append("")
                elif t == "s":
                    r.append(strings[int(v.text)])
                else:
                    r.append(v.text)
            rows.append(r)
        return rows


def main():
    alipay_path = sys.argv[1]
    zhoupu_path = sys.argv[2]

    # 支付宝流水
    alipay_rows = parse_xlsx(alipay_path)[2:]  # skip title+header
    alipay_income = []
    alipay_expense = []
    alipay_withdraw = []

    for row in alipay_rows:
        if not row or len(row) < 7 or not row[0]:
            continue
        dt = excel_date(row[0])
        direction = str(row[5])
        amount = float(row[6]) if row[6] else 0
        counterparty = str(row[2]) if len(row) > 2 else ""
        payment_method = str(row[7]) if len(row) > 7 else ""
        remark = str(row[11]) if len(row) > 11 else ""
        category = str(row[1]) if len(row) > 1 else ""
        item = {"date": dt, "counterparty": counterparty, "amount": amount,
                "payment": payment_method, "remark": remark, "category": category}
        if direction == "收入":
            alipay_income.append(item)
        elif direction == "支出":
            alipay_expense.append(item)
        elif direction == "不计收支":
            alipay_withdraw.append(item)

    # 舟谱支付宝
    zhoupu_rows = parse_xlsx(zhoupu_path)
    headers = zhoupu_rows[4]
    col_idx = {h.strip(): i for i, h in enumerate(headers)}
    zhoupu_income = []
    zhoupu_expense = []

    for row in zhoupu_rows[5:]:
        if not row or len(row) < 10:
            continue
        if str(row[0]) != "1003021":
            continue
        doc_type = str(row[col_idx.get("单据类型", 4)])
        income_val = row[col_idx.get("收入", 6)]
        expense_val = row[col_idx.get("支出", 7)]
        remark = str(row[col_idx.get("备注", 12)])
        counterparty = str(row[col_idx.get("结算单位", 9)])
        income_amt = float(income_val) if income_val and income_val not in ("", "None") else 0
        expense_amt = float(expense_val) if expense_val and expense_val not in ("", "None") else 0
        if doc_type == "期初余额":
            continue
        if income_amt > 0:
            zhoupu_income.append({"date": str(row[col_idx.get("单据时间", 2)])[:10],
                                  "counterparty": counterparty, "amount": income_amt,
                                  "doc_type": doc_type, "remark": remark})
        if expense_amt > 0:
            zhoupu_expense.append({"date": str(row[col_idx.get("单据时间", 2)])[:10],
                                   "counterparty": counterparty, "amount": expense_amt,
                                   "doc_type": doc_type, "remark": remark})

    # 收入匹配（纯金额，不限日期）
    matched_income = []
    for zi in zhoupu_income:
        for ai in alipay_income:
            if ai["amount"] == zi["amount"] and ai not in [m[1] for m in matched_income]:
                matched_income.append((zi, ai))
                break

    used_ai = set(id(m[1]) for m in matched_income)
    unmatched_ai = [ai for ai in alipay_income if id(ai) not in used_ai]
    unmatched_zi = [zi for zi in zhoupu_income if zi not in [m[0] for m in matched_income]]

    # 支出匹配（纯金额）
    matched_expense = []
    for ze in zhoupu_expense:
        for ae in alipay_expense:
            if ae["amount"] == ze["amount"] and ae not in [m[1] for m in matched_expense]:
                matched_expense.append((ze, ae))
                break

    used_ae = set(id(m[1]) for m in matched_expense)
    unmatched_ae = [ae for ae in alipay_expense if id(ae) not in used_ae]
    unmatched_ze = [ze for ze in zhoupu_expense if ze not in [m[0] for m in matched_expense]]

    # 输出报告
    print("=" * 60)
    print("支付宝对账报告（2026年3月）")
    print("=" * 60)
    print("\n## 账户：张俊峰支付宝 (1003021)")
    print("\n| 项目 | 支付宝流水 | 舟谱(1003021) |")
    print("|------|-----------|---------------|")
    print("| 收入 | ¥%.2f（%d笔） | ¥%.2f（%d笔） |" % (
        sum(i["amount"] for i in alipay_income), len(alipay_income),
        sum(i["amount"] for i in zhoupu_income), len(zhoupu_income)))
    print("| 支出 | ¥%.2f（%d笔） | ¥%.2f（%d笔） |" % (
        sum(i["amount"] for i in alipay_expense), len(alipay_expense),
        sum(i["amount"] for i in zhoupu_expense), len(zhoupu_expense)))
    print("| 提现到银行卡 | ¥%.2f（%d笔） | — |" % (
        sum(i["amount"] for i in alipay_withdraw), len(alipay_withdraw)))
    print("\n**已匹配：收入 %d 组，支出 %d 组**" % (len(matched_income), len(matched_expense)))

    if matched_income:
        print("\n### 收入匹配明细（舟谱日期 vs 支付宝日期）")
        print("| 舟谱日期 | 舟谱对方 | 金额 | 支付宝日期 | 支付宝对方 | 备注 |")
        print("|----------|----------|------|------------|------------|------|")
        for zi, ai in matched_income:
            d1 = zi["date"][:10]
            d2 = ai["date"].strftime("%m-%d")
            flag = "⚠️ 日期偏差" if d1 != d2 else ""
            print("| %s | %s | ¥%.2f | %s | %s | %s |" % (
                d1, zi["counterparty"], zi["amount"], d2, ai["counterparty"], flag))

    if unmatched_ai:
        print("\n### 未匹配收入（支付宝有，舟谱无）- %d笔" % len(unmatched_ai))
        print("| 时间 | 对方 | 金额 | 备注 | 建议 |")
        print("|------|------|------|------|------|")
        for i in unmatched_ai:
            print("| %s | %s | ¥%.2f | %s | 补录 |" % (
                i["date"].strftime("%m-%d"), i["counterparty"], i["amount"], i["remark"]))
        print("| **合计** | | **¥%.2f** | | |" % sum(i["amount"] for i in unmatched_ai))

    if unmatched_zi:
        print("\n### 未匹配收入（舟谱有，支付宝无）- %d笔" % len(unmatched_zi))
        print("| 时间 | 对方 | 金额 | 单据类型 | 备注 | 建议 |")
        print("|------|------|------|----------|------|------|")
        for i in unmatched_zi:
            print("| %s | %s | ¥%.2f | %s | %s | 核查 |" % (
                i["date"][:10], i["counterparty"], i["amount"], i["doc_type"], i["remark"]))
        print("| **合计** | | **¥%.2f** | | |" % sum(i["amount"] for i in unmatched_zi))

    if unmatched_ae:
        # 分离服务费和其他
        fee = [i for i in unmatched_ae if "支付宝" in i["counterparty"]]
        other = [i for i in unmatched_ae if "支付宝" not in i["counterparty"]]
        if fee:
            print("\n### 未匹配支出（支付宝服务费，舟谱可能未记）- %d笔" % len(fee))
            print("| 时间 | 对方 | 金额 | 备注 | 建议 |")
            print("|------|------|------|------|------|")
            for i in fee:
                print("| %s | %s | ¥%.2f | %s | 记入财务费用 |" % (
                    i["date"].strftime("%m-%d"), i["counterparty"], i["amount"], i["remark"]))
            print("| **合计** | | **¥%.2f** | | |" % sum(i["amount"] for i in fee))
        if other:
            print("\n### 未匹配支出（支付宝有，舟谱无）- %d笔" % len(other))
            print("| 时间 | 对方 | 金额 | 备注 | 建议 |")
            print("|------|------|------|------|------|")
            for i in other:
                print("| %s | %s | ¥%.2f | %s | 补录 |" % (
                    i["date"].strftime("%m-%d"), i["counterparty"], i["amount"], i["remark"]))
            print("| **合计** | | **¥%.2f** | | |" % sum(i["amount"] for i in other))

    if unmatched_ze:
        print("\n### 未匹配支出（舟谱有，支付宝无）- %d笔" % len(unmatched_ze))
        print("| 时间 | 对方 | 金额 | 单据类型 | 备注 | 建议 |")
        print("|------|------|------|----------|------|------|")
        for i in unmatched_ze:
            print("| %s | %s | ¥%.2f | %s | %s | 核查 |" % (
                i["date"][:10], i["counterparty"], i["amount"], i["doc_type"], i["remark"]))
        print("| **合计** | | **¥%.2f** | | |" % sum(i["amount"] for i in unmatched_ze))

    if alipay_withdraw:
        print("\n### 提现记录（支付宝→银行卡，共%d笔，金额¥%.2f）" % (
            len(alipay_withdraw), sum(i["amount"] for i in alipay_withdraw)))
        print("（提现到银行卡不计入支付宝账户对账，在银行账户对账中处理）")
        print("\n| 时间 | 类型 | 金额 | 方式 |")
        print("|------|------|------|------|")
        for i in alipay_withdraw:
            print("| %s | %s | ¥%.2f | %s |" % (
                i["date"].strftime("%m-%d"), i["category"], i["amount"], i["payment"]))


if __name__ == "__main__":
    main()
