#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
银行流水对账脚本 v2.1 (轻量版，无pandas依赖)
"""

import csv
import re
from datetime import datetime, timedelta
import argparse
import os

FEE_RATE = 0.002791
INTERNAL_ACCOUNTS = ['张俊峰', '谢雯']
THIRD_PARTY_KEYWORDS = ['微企', '随行付', '微企付']


def parse_amount(val):
    if not val:
        return 0.0
    s = str(val).replace(',', '').replace(' ', '').replace('，', '').replace('¥', '')
    try:
        return float(s) if s else 0.0
    except:
        return 0.0


def normalize_date(val):
    if not val or str(val).strip() in ('', 'nan', 'NaT', 'None'):
        return None
    s = str(val).split('.')[0].strip()
    for fmt in ['%Y-%m-%d %H:%M:%S', '%Y-%m-%d', '%Y/%m/%d %H:%M:%S', '%Y/%m/%d']:
        try:
            return datetime.strptime(s, fmt)
        except:
            continue
    # 尝试 Excel 日期序列号
    try:
        from xlrd import xldate_as_tuple
        dt = xldate_as_tuple(float(s), 0)
        return datetime(*dt[:6])
    except:
        pass
    return None


def read_excel_simple(path, sheet_idx=0):
    """简单读取Excel，返回行列表"""
    try:
        import openpyxl
        wb = openpyxl.load_workbook(path, data_only=True)
        sheet = wb.worksheets[sheet_idx]
        rows = []
        for row in sheet.iter_rows(values_only=True):
            rows.append(list(row))
        return rows
    except ImportError:
        pass
    
    try:
        import xlrd
        wb = xlrd.open_workbook(path)
        sheet = wb.sheet_by_index(sheet_idx)
        rows = []
        for i in range(sheet.nrows):
            rows.append(sheet.row_values(i))
        return rows
    except ImportError:
        pass
    
    raise ImportError("需要 openpyxl 或 xlrd 来读取Excel文件")


def load_bank(path):
    rows = read_excel_simple(path, 0)
    # 跳过前2行（标题+表头）
    data_rows = rows[2:] if len(rows) > 2 else rows
    
    records = []
    for row in data_rows:
        if len(row) < 10:
            continue
        
        # 列：凭证号,本方账号,对方账号,交易时间,借贷,借方发生额,贷方发生额,对方行号,摘要,用途,对方单位名称,余额,个性化信息
        date = normalize_date(row[3] if len(row) > 3 else None)
        if not date:
            continue
        
        debit = parse_amount(row[5] if len(row) > 5 else 0)
        credit = parse_amount(row[6] if len(row) > 6 else 0)
        if debit == 0 and credit == 0:
            continue
        
        desc = str(row[8]) if len(row) > 8 and row[8] else ''
        cp = str(row[10]) if len(row) > 10 and row[10] else ''
        is_third = any(k in desc or k in cp for k in THIRD_PARTY_KEYWORDS)
        is_internal = any(k in cp for k in INTERNAL_ACCOUNTS)
        
        if debit > 0:
            records.append({
                'date': date, 'amount': debit, 'direction': 'debit',
                'desc': desc, 'cp': cp, 'is_third': False,
                'is_internal': is_internal, 'matched': False
            })
        if credit > 0:
            records.append({
                'date': date, 'amount': credit, 'direction': 'credit',
                'desc': desc, 'cp': cp, 'is_third': is_third,
                'is_internal': is_internal, 'matched': False
            })
    return records


def load_finance(path):
    rows = read_excel_simple(path, 0)
    # 跳过前5行
    data_rows = rows[5:] if len(rows) > 5 else rows
    
    records = []
    for row in data_rows:
        if len(row) < 10:
            continue
        
        # 列：账户编号,账户名称,单据时间,单据编号,单据类型,单据状态,收入,支出,账户余额,结算单位,供应商,收付款人,备注
        date = normalize_date(row[2] if len(row) > 2 else None)
        if not date:
            continue
        
        income = parse_amount(row[6] if len(row) > 6 else 0)
        expense = parse_amount(row[7] if len(row) > 7 else 0)
        if income == 0 and expense == 0:
            continue
        
        cp = ''
        if len(row) > 11 and row[11]:
            cp = str(row[11]).strip()
        elif len(row) > 10 and row[10]:
            cp = str(row[10]).strip()
        
        if income > 0:
            records.append({
                'date': date, 'amount': income, 'direction': 'income',
                'cp': cp, 'matched': False
            })
        if expense > 0:
            records.append({
                'date': date, 'amount': expense, 'direction': 'expense',
                'cp': cp, 'matched': False
            })
    return records


def match_expense(bank_records, finance_records):
    bank_debits = [r for r in bank_records if r['direction'] == 'debit']
    fin_expenses = [r for r in finance_records if r['direction'] == 'expense']
    
    matched = []
    for b in bank_debits:
        for f in fin_expenses:
            if f['matched']:
                continue
            if abs(b['amount'] - f['amount']) < 0.01 and b['date'].date() == f['date'].date():
                matched.append({'bank': b, 'finance': f})
                b['matched'] = True
                f['matched'] = True
                break
    
    unmatched_bank = [r for r in bank_debits if not r['matched']]
    unmatched_fin = [r for r in fin_expenses if not r['matched']]
    return matched, unmatched_bank, unmatched_fin


def match_income_third_party(bank_records, finance_records, month_end_date=None):
    bank_thirds = [r for r in bank_records if r['direction'] == 'credit' and r['is_third']]
    fin_incomes = [r for r in finance_records if r['direction'] == 'income']
    
    fin_by_date = {}
    for r in fin_incomes:
        if r['matched']:
            continue
        dk = r['date'].strftime('%Y-%m-%d')
        fin_by_date.setdefault(dk, []).append(r)
    
    matched = []
    cross_month = []
    
    for b in bank_thirds:
        if b['matched']:
            continue
        prev_date = b['date'] - timedelta(days=1)
        prev_key = prev_date.strftime('%Y-%m-%d')
        
        if prev_key in fin_by_date:
            candidates = [r for r in fin_by_date[prev_key] if not r['matched']]
            if candidates:
                total = sum(r['amount'] for r in candidates)
                expected = total * (1 - FEE_RATE)
                if abs(b['amount'] - expected) < 1.0:
                    matched.append({
                        'bank': b, 'finance_records': candidates,
                        'total_fin': total, 'expected_bank': expected,
                        'fee': total - b['amount']
                    })
                    b['matched'] = True
                    for r in candidates:
                        r['matched'] = True
        else:
            if month_end_date and prev_date.date() == month_end_date:
                cross_month.append(b)
    
    unmatched_bank = [r for r in bank_thirds if not r['matched'] and r not in cross_month]
    return matched, unmatched_bank, cross_month


def match_income_direct(bank_records, finance_records):
    bank_directs = [r for r in bank_records if r['direction'] == 'credit' and not r['is_third']]
    fin_incomes = [r for r in finance_records if r['direction'] == 'income' and not r['matched']]
    
    matched = []
    for b in bank_directs:
        if b['matched']:
            continue
        for f in fin_incomes:
            if f['matched']:
                continue
            if abs(b['amount'] - f['amount']) < 0.01 and b['date'].date() == f['date'].date():
                matched.append({'bank': b, 'finance': f})
                b['matched'] = True
                f['matched'] = True
                break
    
    unmatched_bank = [r for r in bank_directs if not r['matched']]
    unmatched_fin = [r for r in fin_incomes if not r['matched']]
    return matched, unmatched_bank, unmatched_fin


def print_section(title):
    print(f"\n{'='*60}")
    print(f"  {title}")
    print('='*60)


def fmt_amount(v):
    return f"¥{v:,.2f}"


def main():
    parser = argparse.ArgumentParser(description='银行流水对账工具 v2.1')
    parser.add_argument('--bank', '-b', required=True, help='工行流水文件路径')
    parser.add_argument('--finance', '-f', required=True, help='舟谱系统文件路径')
    parser.add_argument('--month-end', '-m', help='月末日期 YYYY-MM-DD')
    args = parser.parse_args()
    
    month_end = None
    if args.month_end:
        try:
            month_end = datetime.strptime(args.month_end, '%Y-%m-%d').date()
        except:
            print(f"⚠️  月末日期格式错误，应为 YYYY-MM-DD")
    
    print_section("🏦 银行流水对账 v2.1")
    print(f"  银行流水: {args.bank}")
    print(f"  舟谱系统: {args.finance}")
    
    print("\n📂 加载数据...")
    bank = load_bank(args.bank)
    finance = load_finance(args.finance)
    
    bank_debits = [r for r in bank if r['direction'] == 'debit']
    bank_credits = [r for r in bank if r['direction'] == 'credit']
    fin_expenses = [r for r in finance if r['direction'] == 'expense']
    fin_incomes = [r for r in finance if r['direction'] == 'income']
    
    print(f"  银行借方（支出）: {len(bank_debits)} 条  合计 {fmt_amount(sum(r['amount'] for r in bank_debits))}")
    print(f"  银行贷方（收入）: {len(bank_credits)} 条  合计 {fmt_amount(sum(r['amount'] for r in bank_credits))}")
    print(f"  舟谱支出:         {len(fin_expenses)} 条  合计 {fmt_amount(sum(r['amount'] for r in fin_expenses))}")
    print(f"  舟谱收入:         {len(fin_incomes)} 条  合计 {fmt_amount(sum(r['amount'] for r in fin_incomes))}")
    
    # 支出对账
    print_section("① 支出对账（银行借方 vs 舟谱支出）")
    exp_matched, exp_unmatched_bank, exp_unmatched_fin = match_expense(bank, finance)
    print(f"  ✅ 匹配: {len(exp_matched)} 条")
    print(f"  ❌ 银行有、舟谱无: {len(exp_unmatched_bank)} 条")
    if exp_unmatched_bank:
        for r in exp_unmatched_bank:
            flag = "【内部转账】" if r['is_internal'] else ""
            print(f"     {r['date'].strftime('%m/%d')}  {fmt_amount(r['amount'])}  {r['cp']} {flag}")
    print(f"  ❌ 舟谱有、银行无: {len(exp_unmatched_fin)} 条")
    if exp_unmatched_fin:
        for r in exp_unmatched_fin:
            print(f"     {r['date'].strftime('%m/%d')}  {fmt_amount(r['amount'])}  {r['cp']}")
    
    # T+1对账
    print_section("② 收入对账 - 第三方支付（T+1 + 手续费）")
    t1_matched, t1_unmatched_bank, cross_month = match_income_third_party(bank, finance, month_end)
    print(f"  ✅ T+1匹配: {len(t1_matched)} 天  手续费率 {FEE_RATE*100:.4f}%")
    if t1_matched:
        total_fee = sum(m['fee'] for m in t1_matched)
        print(f"     累计手续费: {fmt_amount(total_fee)}")
    if cross_month:
        print(f"  ⏳ 跨月待确认: {len(cross_month)} 条")
        for r in cross_month:
            print(f"     {r['date'].strftime('%m/%d')}  {fmt_amount(r['amount'])}")
    if t1_unmatched_bank:
        print(f"  ❌ 未匹配第三方到账: {len(t1_unmatched_bank)} 条")
        for r in t1_unmatched_bank:
            print(f"     {r['date'].strftime('%m/%d')}  {fmt_amount(r['amount'])}  {r['cp']}")
    
    # 直接转账对账
    print_section("③ 收入对账 - 直接转账")
    dir_matched, dir_unmatched_bank, dir_unmatched_fin = match_income_direct(bank, finance)
    print(f"  ✅ 匹配: {len(dir_matched)} 条")
    print(f"  ❌ 银行有、舟谱无: {len(dir_unmatched_bank)} 条")
    if dir_unmatched_bank:
        for r in dir_unmatched_bank:
            flag = "【内部转账】" if r['is_internal'] else ""
            print(f"     {r['date'].strftime('%m/%d')}  {fmt_amount(r['amount'])}  {r['cp']} {flag}")
    print(f"  ❌ 舟谱有、银行无: {len(dir_unmatched_fin)} 条")
    if dir_unmatched_fin:
        for r in dir_unmatched_fin:
            print(f"     {r['date'].strftime('%m/%d')}  {fmt_amount(r['amount'])}  {r['cp']}")
    
    # 汇总
    print_section("📊 汇总")
    total_bank = len(bank_debits) + len(bank_credits)
    total_matched = len(exp_matched) + len(t1_matched) + len(dir_matched)
    match_rate = total_matched / total_bank * 100 if total_bank else 0
    print(f"  银行总记录: {total_bank} 条")
    print(f"  匹配成功:   {total_matched} 条  ({match_rate:.1f}%)")
    if bank_debits:
        print(f"  支出匹配率: {len(exp_matched)}/{len(bank_debits)} ({len(exp_matched)/len(bank_debits)*100:.1f}%)")
    if bank_credits:
        print(f"  收入匹配率: {len(t1_matched)+len(dir_matched)}/{len(bank_credits)} ({(len(t1_matched)+len(dir_matched))/len(bank_credits)*100:.1f}%)")
    
    print("\n✅ 对账完成\n")


if __name__ == '__main__':
    main()
