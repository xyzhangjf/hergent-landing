#!/usr/bin/env python3
"""从PDF提取交易流水文本，用于对账前的数据准备"""
import pypdfium2 as pdfium
import sys

if len(sys.argv) < 2:
    print("Usage: python3 pdf_extract.py <file.pdf>")
    sys.exit(1)

pdf_path = sys.argv[1]
pdf = pdfium.PdfDocument(pdf_path)

for i in range(len(pdf)):
    textpage = pdf[i].get_textpage()
    text = textpage.get_text_range()
    print(f"=== Page {i+1} ===")
    print(text)
