#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
银行流水对账脚本 v2.0
基于实战经验重写，支持：
- 命令行参数指定文件路径
- 支出/收入分类对账
- 支出：同日同金额精确匹配
- 收入-第三方支付：T+1 + 手续费匹配
- 收入-直接转账：同日同金额匹配
- 跨月项自动标注
- 内部转账自动识别
"""

import pandas as pd
from datetime import datetime, timedelta
import argparse
import os
import sys

FEE_RATE = 0.002791  # 0.2791% 微企付/随行付手续费率

# 内部账户关键词（不走舟谱工行账户的内部转账）
INTERNAL_ACCOUNTS = ['张俊峰', '谢雯']

# 第三方支付关键词
THIRD_PARTY_KEYWORDS = ['微企', '随行付', '微企付']


def parse_amount(val):
    """解析金额，支持字符串和数值"""
    if pd.isna(val):
        return 0.0
    try:
        if isinstance(val, str):
            return float(val.replace(',', '').replace(' ', '').replace('，', ''))
        return float(val)
    except:
        return 0.0


def normalize_date(val):
    """标准化日期为 datetime 对象"""
    if not val or str(val).strip() in ('', 'nan', 'NaT', 'None'):
        return None
    s = str(val).split('.')[0].strip()
    for fmt in ['%Y-%m-%d %H:%M:%S', '%Y-%m-%d', '%Y/%m/%d %H:%M:%S', '%Y/%m/%d']:
        try:
            return datetime.strptime(s, fmt)
        except:
            continue
    return None


def load_bank(path):
    """加载工行流水"""
    df = pd.read_excel(path, sheet_name='Sheet0', skiprows=1)
    df.columns = ['凭证号', '本方账号', '对方账号', '交易时间', '借贷', '借方发生额',
                  '贷方发生额', '对方行号', '摘要', '用途', '对方单位名称', '余额', '个性化信息']
    df = df.iloc[1:].reset_index(drop=True)

    records = []
    for _, row in df.iterrows():
        debit = parse_amount(row['借方发生额'])
        credit = parse_amount(row['贷方发生额'])
        if debit == 0 and credit == 0:
            continue

        date = normalize_date(row['交易时间'])
        if not date:
            continue

        desc = str(row['摘要']) if pd.notna(row['摘要']) else ''
        cp = str(row['对方单位名称']) if pd.notna(row['对方单位名称']) else ''
        is_third = any(k in desc or k in cp for k in THIRD_PARTY_KEYWORDS)
        is_internal = any(k in cp for k in INTERNAL_ACCOUNTS)

        if debit > 0:
            records.append({
                'date': date, 'amount': debit, 'direction': 'debit',
                'desc': desc, 'cp': cp, 'is_third': False,
                'is_internal': is_internal, 'matched': False, 'raw': row
            })
        if credit > 0:
            records.append({
                'date': date, 'amount': credit, 'direction': 'credit',
                'desc': desc, 'cp': cp, 'is_third': is_third,
                'is_internal': is_internal, 'matched': False, 'raw': row
            })
    return records


def load_finance(path):
    """加载舟谱系统流水"""
    df = pd.read_excel(path, sheet_name='账户收支明细', skiprows=4)
    df.columns = ['账户编号', '账户名称', '单据时间', '单据编号', '单据类型', '单据状态',
                  '收入', '支出', '账户余额', '结算单位', '供应商', '收付款人', '备注']
    df = df.iloc[1:].reset_index(drop=True)

    records = []
    for _, row in df.iterrows():
        date = normalize_date(row['单据时间'])
        if not date:
            continue

        income = parse_amount(row['收入'])
        expense = parse_amount(row['支出'])
        if income == 0 and expense == 0:
            continue

        cp = ''
        if pd.notna(row['收付款人']) and str(row['收付款人']).strip():
            cp = str(row['收付款人']).strip()
        elif pd.notna(row['供应商']) and str(row['供应商']).strip():
            cp = str(row['供应商']).strip()

        if income > 0:
            records.append({
                'date': date, 'amount': income, 'direction': 'income',
                'cp': cp, 'matched': False, 'raw': row
            })
        if expense > 0:
            records.append({
                'date': date, 'amount': expense, 'direction': 'expense',
                'cp': cp, 'matched': False, 'raw': row
            })
    return records


def match_expense(bank_records, finance_records):
    """支出对账：银行借方 vs 舟谱支出，同日同金额精确匹配"""
    bank_debits = [r for r in bank_records if r['direction'] == 'debit']
    fin_expenses = [r for r in finance_records if r['direction'] == 'expense']

    matched = []
    for b in bank_debits:
        for f in fin_expenses:
            if f['matched']:
                continue
            if abs(b['amount'] - f['amount']) < 0.01 and b['date'].date() == f['date'].date():
                matched.append({'bank': b, 'finance': f})
                b['matched'] = True
                f['matched'] = True
                break

    unmatched_bank = [r for r in bank_debits if not r['matched']]
    unmatched_fin = [r for r in fin_expenses if not r['matched']]
    return matched, unmatched_bank, unmatched_fin


def match_income_third_party(bank_records, finance_records, month_end_date=None):
    """
    第三方支付收入对账：T+1 + 手续费
    银行贷方（微企付/随行付）= 舟谱前一天收入汇总 × (1 - 0.2791%)
    """
    bank_thirds = [r for r in bank_records if r['direction'] == 'credit' and r['is_third']]
    fin_incomes = [r for r in finance_records if r['direction'] == 'income']

    # 按日期聚合舟谱收入
    fin_by_date = {}
    for r in fin_incomes:
        if r['matched']:
            continue
        dk = r['date'].strftime('%Y-%m-%d')
        fin_by_date.setdefault(dk, []).append(r)

    matched = []
    cross_month = []

    for b in bank_thirds:
        if b['matched']:
            continue
        prev_date = b['date'] - timedelta(days=1)
        prev_key = prev_date.strftime('%Y-%m-%d')

        if prev_key in fin_by_date:
            candidates = [r for r in fin_by_date[prev_key] if not r['matched']]
            if candidates:
                total = sum(r['amount'] for r in candidates)
                expected = total * (1 - FEE_RATE)
                if abs(b['amount'] - expected) < 1.0:
                    matched.append({
                        'bank': b, 'finance_records': candidates,
                        'total_fin': total, 'expected_bank': expected,
                        'fee': total - b['amount']
                    })
                    b['matched'] = True
                    for r in candidates:
                        r['matched'] = True
        else:
            # 月末跨月：舟谱当天收入，银行次月才到账
            if month_end_date and prev_date.date() == month_end_date:
                cross_month.append(b)

    unmatched_bank = [r for r in bank_thirds if not r['matched'] and r not in cross_month]
    return matched, unmatched_bank, cross_month


def match_income_direct(bank_records, finance_records):
    """直接转账收入对账：银行贷方（非第三方）vs 舟谱收入，同日同金额"""
    bank_directs = [r for r in bank_records if r['direction'] == 'credit' and not r['is_third']]
    fin_incomes = [r for r in finance_records if r['direction'] == 'income' and not r['matched']]

    matched = []
    for b in bank_directs:
        if b['matched']:
            continue
        for f in fin_incomes:
            if f['matched']:
                continue
            if abs(b['amount'] - f['amount']) < 0.01 and b['date'].date() == f['date'].date():
                matched.append({'bank': b, 'finance': f})
                b['matched'] = True
                f['matched'] = True
                break

    unmatched_bank = [r for r in bank_directs if not r['matched']]
    unmatched_fin = [r for r in fin_incomes if not r['matched']]
    return matched, unmatched_bank, unmatched_fin


def print_section(title):
    print(f"\n{'='*60}")
    print(f"  {title}")
    print('='*60)


def fmt_amount(v):
    return f"¥{v:,.2f}"


def main():
    parser = argparse.ArgumentParser(description='银行流水对账工具 v2.0')
    parser.add_argument('--bank', '-b', required=True, help='工行流水文件路径')
    parser.add_argument('--finance', '-f', required=True, help='舟谱系统文件路径')
    parser.add_argument('--month-end', '-m', help='月末日期 YYYY-MM-DD，用于识别跨月T+1项')
    parser.add_argument('--output', '-o', help='输出Excel报告路径（可选）')
    args = parser.parse_args()

    month_end = None
    if args.month_end:
        try:
            month_end = datetime.strptime(args.month_end, '%Y-%m-%d').date()
        except:
            print(f"⚠️  月末日期格式错误，应为 YYYY-MM-DD，已忽略")

    print_section("🏦 银行流水对账 v2.0")
    print(f"  银行流水: {args.bank}")
    print(f"  舟谱系统: {args.finance}")

    # 加载数据
    print("\n📂 加载数据...")
    bank = load_bank(args.bank)
    finance = load_finance(args.finance)

    bank_debits = [r for r in bank if r['direction'] == 'debit']
    bank_credits = [r for r in bank if r['direction'] == 'credit']
    fin_expenses = [r for r in finance if r['direction'] == 'expense']
    fin_incomes = [r for r in finance if r['direction'] == 'income']

    print(f"  银行借方（支出）: {len(bank_debits)} 条  合计 {fmt_amount(sum(r['amount'] for r in bank_debits))}")
    print(f"  银行贷方（收入）: {len(bank_credits)} 条  合计 {fmt_amount(sum(r['amount'] for r in bank_credits))}")
    print(f"  舟谱支出:         {len(fin_expenses)} 条  合计 {fmt_amount(sum(r['amount'] for r in fin_expenses))}")
    print(f"  舟谱收入:         {len(fin_incomes)} 条  合计 {fmt_amount(sum(r['amount'] for r in fin_incomes))}")

    # ── 支出对账 ──
    print_section("① 支出对账（银行借方 vs 舟谱支出）")
    exp_matched, exp_unmatched_bank, exp_unmatched_fin = match_expense(bank, finance)
    print(f"  ✅ 匹配: {len(exp_matched)} 条")
    print(f"  ❌ 银行有、舟谱无: {len(exp_unmatched_bank)} 条")
    if exp_unmatched_bank:
        for r in exp_unmatched_bank:
            flag = "【内部转账】" if r['is_internal'] else ""
            print(f"     {r['date'].strftime('%m/%d')}  {fmt_amount(r['amount'])}  {r['cp']} {flag}")
    print(f"  ❌ 舟谱有、银行无: {len(exp_unmatched_fin)} 条")
    if exp_unmatched_fin:
        for r in exp_unmatched_fin:
            print(f"     {r['date'].strftime('%m/%d')}  {fmt_amount(r['amount'])}  {r['cp']}")

    # ── 收入-第三方支付 ──
    print_section("② 收入对账 - 第三方支付（T+1 + 手续费）")
    t1_matched, t1_unmatched_bank, cross_month = match_income_third_party(bank, finance, month_end)
    print(f"  ✅ T+1匹配: {len(t1_matched)} 天  手续费率 {FEE_RATE*100:.4f}%")
    if t1_matched:
        total_fee = sum(m['fee'] for m in t1_matched)
        print(f"     累计手续费: {fmt_amount(total_fee)}")
    if cross_month:
        print(f"  ⏳ 跨月待确认（月末收款，次月到账）: {len(cross_month)} 条")
        for r in cross_month:
            print(f"     {r['date'].strftime('%m/%d')}  {fmt_amount(r['amount'])}")
    if t1_unmatched_bank:
        print(f"  ❌ 未匹配第三方到账: {len(t1_unmatched_bank)} 条")
        for r in t1_unmatched_bank:
            print(f"     {r['date'].strftime('%m/%d')}  {fmt_amount(r['amount'])}  {r['cp']}")

    # ── 收入-直接转账 ──
    print_section("③ 收入对账 - 直接转账")
    dir_matched, dir_unmatched_bank, dir_unmatched_fin = match_income_direct(bank, finance)
    print(f"  ✅ 匹配: {len(dir_matched)} 条")
    print(f"  ❌ 银行有、舟谱无: {len(dir_unmatched_bank)} 条")
    if dir_unmatched_bank:
        for r in dir_unmatched_bank:
            flag = "【内部转账】" if r['is_internal'] else ""
            print(f"     {r['date'].strftime('%m/%d')}  {fmt_amount(r['amount'])}  {r['cp']} {flag}")
    print(f"  ❌ 舟谱有、银行无: {len(dir_unmatched_fin)} 条")
    if dir_unmatched_fin:
        for r in dir_unmatched_fin:
            print(f"     {r['date'].strftime('%m/%d')}  {fmt_amount(r['amount'])}  {r['cp']}")

    # ── 汇总 ──
    print_section("📊 汇总")
    total_bank = len(bank_debits) + len(bank_credits)
    total_matched = len(exp_matched) + len(t1_matched) + len(dir_matched)
    # T+1匹配中每个bank记录算1条
    match_rate = total_matched / total_bank * 100 if total_bank else 0
    print(f"  银行总记录: {total_bank} 条")
    print(f"  匹配成功:   {total_matched} 条  ({match_rate:.1f}%)")
    print(f"  支出匹配率: {len(exp_matched)}/{len(bank_debits)} ({len(exp_matched)/len(bank_debits)*100:.1f}%)" if bank_debits else "")
    print(f"  收入匹配率: {len(t1_matched)+len(dir_matched)}/{len(bank_credits)} ({(len(t1_matched)+len(dir_matched))/len(bank_credits)*100:.1f}%)" if bank_credits else "")

    # ── 输出报告 ──
    if args.output:
        rows = []
        for m in exp_matched:
            rows.append({'类型': '支出匹配', '银行日期': m['bank']['date'].strftime('%Y-%m-%d'),
                         '银行金额': m['bank']['amount'], '对方': m['bank']['cp'],
                         '舟谱日期': m['finance']['date'].strftime('%Y-%m-%d'),
                         '舟谱金额': m['finance']['amount'], '备注': ''})
        for r in exp_unmatched_bank:
            rows.append({'类型': '支出-银行有舟谱无', '银行日期': r['date'].strftime('%Y-%m-%d'),
                         '银行金额': r['amount'], '对方': r['cp'],
                         '舟谱日期': '', '舟谱金额': '',
                         '备注': '内部转账' if r['is_internal'] else ''})
        for r in exp_unmatched_fin:
            rows.append({'类型': '支出-舟谱有银行无', '银行日期': '', '银行金额': '',
                         '对方': r['cp'], '舟谱日期': r['date'].strftime('%Y-%m-%d'),
                         '舟谱金额': r['amount'], '备注': ''})
        for m in t1_matched:
            rows.append({'类型': 'T+1收入匹配', '银行日期': m['bank']['date'].strftime('%Y-%m-%d'),
                         '银行金额': m['bank']['amount'], '对方': m['bank']['cp'],
                         '舟谱日期': (m['bank']['date']-timedelta(days=1)).strftime('%Y-%m-%d'),
                         '舟谱金额': m['total_fin'],
                         '备注': f"手续费{fmt_amount(m['fee'])}"})
        for r in cross_month:
            rows.append({'类型': '跨月待确认', '银行日期': r['date'].strftime('%Y-%m-%d'),
                         '银行金额': r['amount'], '对方': r['cp'],
                         '舟谱日期': '', '舟谱金额': '', '备注': '月末T+1跨月'})
        for m in dir_matched:
            rows.append({'类型': '直接转账匹配', '银行日期': m['bank']['date'].strftime('%Y-%m-%d'),
                         '银行金额': m['bank']['amount'], '对方': m['bank']['cp'],
                         '舟谱日期': m['finance']['date'].strftime('%Y-%m-%d'),
                         '舟谱金额': m['finance']['amount'], '备注': ''})
        for r in dir_unmatched_bank:
            rows.append({'类型': '收入-银行有舟谱无', '银行日期': r['date'].strftime('%Y-%m-%d'),
                         '银行金额': r['amount'], '对方': r['cp'],
                         '舟谱日期': '', '舟谱金额': '',
                         '备注': '内部转账' if r['is_internal'] else ''})
        for r in dir_unmatched_fin:
            rows.append({'类型': '收入-舟谱有银行无', '银行日期': '', '银行金额': '',
                         '对方': r['cp'], '舟谱日期': r['date'].strftime('%Y-%m-%d'),
                         '舟谱金额': r['amount'], '备注': ''})

        pd.DataFrame(rows).to_excel(args.output, index=False)
        print(f"\n💾 报告已保存: {args.output}")

    print("\n✅ 对账完成\n")


if __name__ == '__main__':
    main()
