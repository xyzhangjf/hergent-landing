#!/usr/bin/env python3
"""
邮储银行流水对账脚本 v3 - 修复版
同日精确匹配 -> 同日合并匹配 -> 跨日精确匹配 -> 跨日合并匹配
"""

import xlrd, openpyxl
from datetime import datetime
from itertools import combinations
import sys

def parse_amount(val):
    if val is None: return 0.0
    try:
        if isinstance(val, str): return float(val.replace(',','').replace(' ','').replace('，',''))
        return float(val)
    except: return 0.0

def normalize_date(val):
    if not val or str(val).strip() in ('', 'nan', 'NaT', 'None'): return None
    s = str(val).split('.')[0].strip()
    for fmt in ['%Y-%m-%d %H:%M', '%Y-%m-%d %H:%M:%S', '%Y-%m-%d', '%Y/%m/%d %H:%M']:
        try: return datetime.strptime(s, fmt)
        except: continue
    if isinstance(val, (int, float)):
        try:
            from xlrd import xldate_as_tuple
            return datetime(*xldate_as_tuple(val, 0))
        except: pass
    return None

def load_bank(path):
    wb = xlrd.open_workbook(path); ws = wb.sheet_by_index(0)
    records = []
    for i in range(3, ws.nrows):
        row = [ws.cell_value(i, j) for j in range(ws.ncols)]
        dt = normalize_date(row[0]); amt = parse_amount(row[5])
        if not dt or amt == 0: continue
        records.append({'date': dt, 'amount': abs(amt), 'direction': 'credit' if amt > 0 else 'debit',
                        'payer': str(row[1]) if row[1] else '', 'payee': str(row[2]) if row[2] else '',
                        'desc': str(row[7]) if row[7] else '', 'remark': str(row[8]) if len(row)>8 and row[8] else ''})
    return records

def load_zhoupu(path, account_ids):
    wb = openpyxl.load_workbook(path); ws = wb.active
    records = []; i = 5; cur_acc = None
    while i < ws.max_row:
        aid = ws.cell(i+1,1).value; anm = ws.cell(i+1,2).value
        if anm and ('小计' in str(anm) or '合计' in str(anm)): i+=1; continue
        if anm and '合计' in str(anm): break
        if aid is not None: cur_acc = str(aid)
        inc = parse_amount(ws.cell(i+1,7).value); exp = parse_amount(ws.cell(i+1,8).value)
        if inc == 0 and exp == 0: i+=1; continue
        if cur_acc in account_ids:
            records.append({'date': normalize_date(ws.cell(i+1,3).value), 'amount': inc if inc>0 else exp,
                            'direction': 'credit' if inc>0 else 'debit',
                            'doc_type': str(ws.cell(i+1,5).value or ''), 'doc_no': str(ws.cell(i+1,4).value or ''),
                            'counterpart': str(ws.cell(i+1,12).value or ''), 'remark': str(ws.cell(i+1,13).value or ''),
                            'account': cur_acc})
        i+=1
    return records

def reconcile(bank_records, zp_records):
    bi = [b for b in bank_records if b['direction']=='credit']
    be = [b for b in bank_records if b['direction']=='debit']
    zi = [z for z in zp_records if z['direction']=='credit']
    ze = [z for z in zp_records if z['direction']=='debit']
    
    used_b_i = set(); used_z_i = set(); m_inc = []
    used_b_e = set(); used_z_e = set(); m_exp = []
    
    # === INCOME ===
    # Pass 1: exact same-day match
    for bi_i, b in enumerate(bi):
        if bi_i in used_b_i: continue
        for zi_i, z in enumerate(zi):
            if zi_i in used_z_i: continue
            if not b['date'] or not z['date']: continue
            if abs((b['date'].date()-z['date'].date()).days) == 0 and abs(b['amount']-z['amount']) < 0.01:
                used_b_i.add(bi_i); used_z_i.add(zi_i)
                m_inc.append({'bank': b, 'zp': [z], 'days': 0})
                break
    
    # Pass 2: same-day combined match
    for bi_i, b in enumerate(bi):
        if bi_i in used_b_i: continue
        avail = [z for zi_i,z in enumerate(zi) if zi_i not in used_z_i and z['direction']=='credit' and z['date'] and abs((b['date'].date()-z['date'].date()).days)==0]
        for n in range(2, min(5, len(avail)+1)):
            for combo in combinations(range(len(avail)), n):
                if abs(sum(avail[j]['amount'] for j in combo) - b['amount']) < 0.01:
                    used_b_i.add(bi_i)
                    for j in combo: used_z_i.add(zi.index(avail[j]))
                    m_inc.append({'bank': b, 'zp': [avail[j] for j in combo], 'days': 0})
                    break
            else: continue
            break
    
    # Pass 3: cross-day exact match (within 3 days for income)
    for bi_i, b in enumerate(bi):
        if bi_i in used_b_i: continue
        for zi_i, z in enumerate(zi):
            if zi_i in used_z_i: continue
            if not b['date'] or not z['date']: continue
            days = abs((b['date'].date()-z['date'].date()).days)
            if 1 <= days <= 3 and abs(b['amount']-z['amount']) < 0.01:
                used_b_i.add(bi_i); used_z_i.add(zi_i)
                m_inc.append({'bank': b, 'zp': [z], 'days': days})
                break
    
    ubi = [b for bi_i,b in enumerate(bi) if bi_i not in used_b_i]
    uzi = [z for zi_i,z in enumerate(zi) if zi_i not in used_z_i]
    
    # === EXPENSE ===
    # Pass 1: exact same-day match (allow 3 day tolerance for expense)
    for bi_i, b in enumerate(be):
        if bi_i in used_b_e: continue
        for zi_i, z in enumerate(ze):
            if zi_i in used_z_e: continue
            if not b['date'] or not z['date']: continue
            days = abs((b['date'].date()-z['date'].date()).days)
            if days == 0 and abs(b['amount']-z['amount']) < 0.01:
                used_b_e.add(bi_i); used_z_e.add(zi_i)
                m_exp.append({'bank': b, 'zp': [z], 'days': 0})
                break
    
    # Pass 2: cross-day exact match (within 5 days for expense)
    for bi_i, b in enumerate(be):
        if bi_i in used_b_e: continue
        for zi_i, z in enumerate(ze):
            if zi_i in used_z_e: continue
            if not b['date'] or not z['date']: continue
            days = abs((b['date'].date()-z['date'].date()).days)
            if 1 <= days <= 5 and abs(b['amount']-z['amount']) < 0.01:
                used_b_e.add(bi_i); used_z_e.add(zi_i)
                m_exp.append({'bank': b, 'zp': [z], 'days': days})
                break
    
    ube = [b for bi_i,b in enumerate(be) if bi_i not in used_b_e]
    uze = [z for zi_i,z in enumerate(ze) if zi_i not in used_z_e]
    
    return m_inc, m_exp, ubi, ube, uzi, uze

def classify_unmatched(ubi, ube, uzi, uze):
    """Classify unmatched items with reason and suggestion"""
    
    # Bank unmatched income
    for b in ubi:
        b['reason'] = '内部转账（公转私）' if '公转私' in b.get('desc','') else                       ('零钱提现/转账（内部账户）' if any(k in b.get('remark','') for k in ['微信零钱提现','支付宝余额提现','投资']) else '核查')
        b['suggestion'] = '核查' if b['reason'] in ['内部转账（公转私）','零钱提现/转账（内部账户）'] else '补录'
    
    # Bank unmatched expense
    for b in ube:
        remark = b['remark']
        if '蒙牛' in remark or '陈列费' in remark or '回款' in remark or '低温' in remark:
            b['reason'], b['suggestion'] = '漏录', '补录'
        elif '借款' in remark:
            b['reason'], b['suggestion'] = '借款（田晓华）', '补录'
        elif b['payee'] == '湖北福宝商贸有限公司':
            b['reason'], b['suggestion'] = '核查', '核查'
        else:
            b['reason'], b['suggestion'] = '核查', '核查'
    
    # ZP unmatched income
    for z in uzi:
        if '10022' in z.get('account',''):
            z['reason'], z['suggestion'] = '内部转账（公户→个人户）', '核查'
        elif any(k in z['doc_type'] for k in ['资金转账','资金调账']):
            z['reason'], z['suggestion'] = '内部转账（个人账户间调拨）', '核查'
        elif '预收款单' in z['doc_type'] or '收款单' in z['doc_type']:
            z['reason'], z['suggestion'] = '核查', '核查'
        else:
            z['reason'], z['suggestion'] = '核查', '核查'
    
    # ZP unmatched expense
    for z in uze:
        if z['amount'] == 0:
            z['reason'], z['suggestion'] = '零金额调整单（不影响余额）', '确认相符'
        elif abs(z['amount'] - 136000) < 0.01 or '三中' in z['remark']:
            z['reason'], z['suggestion'] = '疑似重复录入（另一笔已匹配）', '删除舟谱记录'
        elif '10022' in z.get('account',''):
            z['reason'], z['suggestion'] = '内部转账（公户→个人户）', '核查'
        else:
            z['reason'], z['suggestion'] = '核查', '核查'
    
    return ubi, ube, uzi, uze

def main():
    bank_path = sys.argv[1]
    zhoupu_path = sys.argv[2]
    account_ids = sys.argv[3].split(',') if len(sys.argv)>3 else ['10022','10024']
    
    bank_records = load_bank(bank_path)
    zp_records = load_zhoupu(zhoupu_path, account_ids)
    
    m_inc, m_exp, ubi, ube, uzi, uze = reconcile(bank_records, zp_records)
    ubi, ube, uzi, uze = classify_unmatched(ubi, ube, uzi, uze)
    
    bi = [b for b in bank_records if b['direction']=='credit']
    be = [b for b in bank_records if b['direction']=='debit']
    zi = [z for z in zp_records if z['direction']=='credit']
    ze = [z for z in zp_records if z['direction']=='debit']
    
    bank_inc_total = sum(b['amount'] for b in bi)
    bank_exp_total = sum(b['amount'] for b in be)
    zp_inc_total = sum(z['amount'] for z in zi)
    zp_exp_total = sum(z['amount'] for z in ze)
    
    print(f"邮储银行流水 vs 舟谱邮储账户对账报告（2026年3月）")
    print(f"=" * 80)
    print(f"银行流水（邮储）: {len(bank_records)}笔  收入¥{bank_inc_total:,.2f}  支出¥{bank_exp_total:,.2f}")
    print(f"舟谱邮储账户(10022+10024): {len(zp_records)}笔  收入¥{zp_inc_total:,.2f}  支出¥{zp_exp_total:,.2f}")
    print()
    print(f"## 收入")
    print(f"| 项目 | 金额 |")
    print(f"|------|------|")
    print(f"| 收入 | ¥{bank_inc_total:,.2f} ({len(bi)}笔) |")
    print(f"| 已匹配 | {len(m_inc)}组（包含{sum(len(m['zp']) for m in m_inc)}笔舟谱记录） |")
    print(f"| 未匹配（银行有，舟谱无） | ¥{sum(b['amount'] for b in ubi):,.2f}（{len(ubi)}笔） |")
    print(f"| 未匹配（舟谱有，银行无） | ¥{sum(z['amount'] for z in uzi):,.2f}（{len(uzi)}笔） |")
    print()
    print(f"## 支出")
    print(f"| 项目 | 金额 |")
    print(f"|------|------|")
    print(f"| 支出 | ¥{bank_exp_total:,.2f}（{len(be)}笔） |")
    print(f"| 已匹配 | {len(m_exp)}组（包含{sum(len(m['zp']) for m in m_exp)}笔舟谱记录） |")
    print(f"| 未匹配（银行有，舟谱无） | ¥{sum(b['amount'] for b in ube):,.2f}（{len(ube)}笔） |")
    print(f"| 未匹配（舟谱有，银行无） | ¥{sum(z['amount'] for z in uze):,.2f}（{len(uze)}笔） |")
    print()
    
    print(f"## 未匹配收入：银行有，舟谱无（{len(ubi)}笔）")
    if ubi:
        print(f"| 时间 | 对方 | 金额 | 摘要 | 备注 | 原因 | 建议 |")
        print(f"|------|------|------|------|------|------|------|")
        for b in ubi:
            print(f"| {b['date'].strftime('%Y-%m-%d')} | {b['payee']} | ¥{b['amount']:,.2f} | {b['desc'][:10]} | {b['remark'][:10]} | {b['reason']} | {b['suggestion']} |")
        print(f"| **合计** | | **¥{sum(b['amount'] for b in ubi):,.2f}** | | | |")
    else:
        print("无")
    print()
    
    print(f"## 未匹配收入：舟谱有，银行无（{len(uzi)}笔）")
    if uzi:
        print(f"| 时间 | 对方 | 金额 | 单据类型 | 账户 | 备注 | 原因 | 建议 |")
        print(f"|------|------|------|----------|------|------|------|------|")
        for z in uzi:
            dt = z['date'].strftime('%Y-%m-%d') if z['date'] else 'N/A'
            print(f"| {dt} | {z['counterpart']} | ¥{z['amount']:,.2f} | {z['doc_type']} | {z['account']} | {z['remark'][:10]} | {z['reason']} | {z['suggestion']} |")
        print(f"| **合计** | | **¥{sum(z['amount'] for z in uzi):,.2f}** | | | |")
    else:
        print("无")
    print()
    
    print(f"## 未匹配支出：银行有，舟谱无（{len(ube)}笔）")
    if ube:
        print(f"| 时间 | 对方 | 金额 | 摘要 | 备注 | 原因 | 建议 |")
        print(f"|------|------|------|------|------|------|------|")
        for b in ube:
            print(f"| {b['date'].strftime('%Y-%m-%d')} | {b['payee']} | ¥{b['amount']:,.2f} | {b['desc'][:10]} | {b['remark'][:15]} | {b['reason']} | {b['suggestion']} |")
        print(f"| **合计** | | **¥{sum(b['amount'] for b in ube):,.2f}** | | | |")
    else:
        print("无")
    print()
    
    print(f"## 未匹配支出：舟谱有，银行无（{len(uze)}笔）")
    if uze:
        print(f"| 时间 | 对方 | 金额 | 单据类型 | 账户 | 备注 | 原因 | 建议 |")
        print(f"|------|------|------|----------|------|------|------|------|")
        for z in uze:
            dt = z['date'].strftime('%Y-%m-%d') if z['date'] else 'N/A'
            print(f"| {dt} | {z['counterpart']} | ¥{z['amount']:,.2f} | {z['doc_type']} | {z['account']} | {z['remark'][:15]} | {z['reason']} | {z['suggestion']} |")
        nonzero = [z for z in uze if z['amount'] > 0]
        print(f"| **合计** | | **¥{sum(z['amount'] for z in nonzero):,.2f}** | | | |")
    else:
        print("无")

if __name__ == '__main__':
    main()
